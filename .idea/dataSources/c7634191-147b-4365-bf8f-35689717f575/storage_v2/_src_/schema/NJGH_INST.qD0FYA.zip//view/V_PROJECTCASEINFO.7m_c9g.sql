create view V_PROJECTCASEINFO as
select p.id as pid,
       p.processinstanceid as piid,
       p.fk_business_id as businessId,
       p.businessname,
       p.createtime,
       p.createtype,
       p.mainorganid,
       p.mainorganname,
       p.registerstate,
       p.processstate,
       p.supervisestate,
       p.qybz,
       c.id as cid,
       c.baseid,
       c.projectcode,
       c.projectname,
       c.casecategory,
       c.casecode,
       c.bizid,
       c.volumenumber,
       c.roundnumber,
       c.municipaltype,
       c.municipaltype_max,
       c.hmcstype,
       c.casetype,
       c.ref_declarematterinfo_id as dmid,
       c.glfaajbh,
       c.glfacid,
       dmi.serialno,
       dmi.refdeclareid as did,
       b.xmdm,
       b.gdlx,
       b.sfbl,
       b.xmjsyj,
       j.yjlx,
       j.yjxz
  from pcc_project p
  left join bz_caseinstrelation cr on cr.pid = p.id
  left join bz_projectcase c on c.id = cr.cid
  left join pdt_projectbase b on b.id = c.baseid
  left join bz_declarematterinfo dmi on c.ref_declarematterinfo_id = dmi.id
  left join bz_spyj j on j.cid = c.id
 where p.lifestate != '删除'
/

