create package DP_copydata is


   ---??????????
    procedure copyXzYdSpxx(v_cid1 in integer,v_cid2 in integer);
    ---??????????
    procedure copyGhtjSpxx(v_cid1 in integer,v_cid2 in integer);
       ---?????? (? ? ????)????
    procedure updateFagcXxxx(v_pid  in integer);
    
     ---????????
    procedure copyRzfhData(v_pid1 in integer,v_pid2 in integer);
    
    --复制父案件的基本信息数据
    procedure copyDataForGenerateLand(v_pid               in integer,
                                      v_parentpid         in integer,
                                      v_businessname      in varchar2,
                                      v_businessprocessid in integer,
                                      v_serialno          in varchar2,
                                      v_volumenumber      in integer,
                                      v_roundnumber       in integer,
                                      v_createuserid      in integer,
                                      v_loginname         in varchar2,
                                      v_casecode          in varchar2,
                                      v_projectnumber     in varchar2);
    
    --更新系统项目表信息                                  
    procedure updateProjectInfoForParent(v_parentpid       in integer,
                                         v_pid in integer);

end DP_copydata;

/

