create function SplitPair(str in varchar2, delimiter varchar2) return STR_PAIR_TBL is
      psrc varchar2(1000);
      tempStr varchar2(1000);
      strPair STR_PAIR ;
      tab STR_PAIR_TBL := STR_PAIR_TBL();
      i number := 1;
      j number := 1;
      k number := 0;
  begin
       if str is null then
          return tab;
       end if;

       psrc := str;
       --psrc := replace(psrc,'?',delimiter);
       psrc := replace(psrc,',',delimiter);
       psrc := replace(psrc,'.',delimiter);
       psrc := replace(psrc,' ',delimiter);

       psrc := RTrim(LTrim(psrc, delimiter), delimiter);

       loop
           i := InStr(psrc, delimiter, j);
           if i>0 then
               tempStr := Trim(SubStr(psrc, j, i-j));
               if mod(k,2)=0 then
                   strPair := STR_PAIR(f1 => '',f2 => '');
                   strPair.F1 := tempStr;
               else
                   strPair.F2 := tempStr;
                   tab.extend;
                   tab(tab.Count) := strPair;
               end if;
               --tab.extend;
               --tab(tab.Count) := strPair;
               k := k+1;
               j := i+1;
           end if;
           exit when i=0;
       end loop;

       if j < Length(psrc) then
          tempStr := Trim(SubStr(psrc, j, Length(psrc)+1-j));
          if mod(k,2)=0 then
              strPair := STR_PAIR(f1 => '',f2 => '');
              strPair.F1 := tempStr;
          else
              strPair.F2 := tempStr;
          end if;
          tab.extend;
          tab(tab.Count) := strPair;
       end if;

       return tab;
 end SplitPair;

/

