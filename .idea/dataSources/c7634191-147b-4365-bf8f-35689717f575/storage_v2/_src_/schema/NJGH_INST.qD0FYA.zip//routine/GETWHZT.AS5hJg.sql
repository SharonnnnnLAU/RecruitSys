create function getWhzt(v_pid in integer,v_type  in varchar2) return integer is
  --??????
  result         integer;
  v_processstate varchar2(50);
begin
  select max(p.processstate)
    into v_processstate
    from pcc_project p
    join bz_whrw w
      on p.id = w.pid
    join bz_whrw_relation wr
      on wr.fk_whrw_id = w.id
   where wr.pid = v_pid  and p.lifestate!='??'  and wr.type=v_type;

  if (v_processstate is not null and v_processstate != '??') then
    result := 1;
  else
    result := 0;
  end if;
  return(result);
end getWhzt;

/

