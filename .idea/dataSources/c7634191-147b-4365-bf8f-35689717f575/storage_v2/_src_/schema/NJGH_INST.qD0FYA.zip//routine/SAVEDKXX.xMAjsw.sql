create procedure saveDkxx(lx  in nvarchar2,
                                     cid in integer,

                                     dkid   in nvarchar2,
                                     dkydxz in nvarchar2,
                                     dkydmj in number) is
begin
  if lx = '??' then
    insert into bz_yd_js_dkmx
      (id, cid, Dkid, dkydxz, Dkydmj)
    values
      (s_bz_yd_js_dkmx.nextval, cid, dkid, dkydxz, Dkydmj);
  end if;
  if lx = '??' then
    insert into bz_yd_dz_dkmx
      (id, cid, dkid, dkydxz, dkydmj)
    values
      (s_bz_yd_dz_dkmx.nextval, cid, dkid, dkydxz, Dkydmj);
  end if;
  commit;
end saveDkxx;

/

