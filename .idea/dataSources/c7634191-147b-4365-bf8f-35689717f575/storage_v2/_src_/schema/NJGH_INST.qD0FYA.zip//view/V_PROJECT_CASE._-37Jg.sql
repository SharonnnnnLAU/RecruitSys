create view V_PROJECT_CASE as
select  p.id  as pid,c.id as cid,p.businessname,p.fk_business_id as businessid,p.processinstanceid from pcc_project  p
join  bz_caseinstrelation ci on p.id=ci.pid
join bz_projectcase  c  on c.id=ci.cid
/

