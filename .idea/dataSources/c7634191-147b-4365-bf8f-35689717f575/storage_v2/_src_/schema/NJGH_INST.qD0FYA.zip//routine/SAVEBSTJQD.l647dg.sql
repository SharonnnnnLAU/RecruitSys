create procedure savebstjqd(cid   in integer,
                                       xh    in integer,
                                       clmc  in nvarchar2,
                                       wh    in nvarchar2,
                                       dzwjm in nvarchar2,
                                       clfs  in nvarchar2,
                                       qj    in number) is
  countTj integer;
begin
  insert into bz_sbcl
    (id, cid, xh, clmc, wh, dzwjm, clfs, qj)
  values
    (s_bz_sbcl.nextval, cid, xh, clmc, wh, dzwjm, clfs, qj);
  commit;
end savebstjqd;

/

