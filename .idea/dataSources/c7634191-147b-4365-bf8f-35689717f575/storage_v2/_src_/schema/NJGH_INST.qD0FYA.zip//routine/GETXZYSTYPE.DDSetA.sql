create function getXzysType(v_pid in integer,v_taskId in integer) return varchar2 is
       --??????
  result varchar2(200);
  userId varchar2(50);
  assign varchar2(50);
  showName varchar2(50);
  actName varchar2(50);
begin
        SELECT p.fromtaskid ,p.userid ,p.activityname into assign, userId,actName from
        (SELECT t.fromtaskid ,t.userid ,t.activityname
        FROM pcc_tasklog t
        WHERE t.projectid =v_pid and connect_by_isleaf=1
        START WITH t.taskid =v_taskId 
        CONNECT BY PRIOR t.fromtaskid = t.taskid AND t.activityname!='分配') p where rownum=1;
        
        if (userId is not null and assign is not null and actName is not null) then
            select p.showname into showName from pcc_sendconfig p 
            where p.assigntaskid=assign and instr(p.userids,userId)>0 and p.showname in ('会办科室','会办初审','会办分局','初审','初审 ')
            and p.activityname=actName and rownum=1 ;
        else
          result :='暂无数据';
        end if;
        case when showName='会办初审' then
             result:='内部会办指派人';
             when showName='会办科室' then
             result:='内部会办指派科室';
             when showName='会办分局' then
             result:='外部会办';
             else 
             result:='主办';   
        end case;
       
return(result);
end getXzysType;
/

