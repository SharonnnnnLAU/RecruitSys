create function connectColbFiledByCid(v_cid in integer)
  return clob is
  result clob;
begin

  for i in (select nn.yj from bz_opinion nn where nn.cid = v_cid) loop
    result := result || i.yj;
  end loop;

  return(result);
end connectColbFiledByCid;
/

