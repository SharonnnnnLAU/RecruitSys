create FUNCTION GET_STRING_TAB (v_str in varchar2, v_split in varchar2) return array pipelined as
  v_new_str varchar2(8000);
begin
  if v_str is null then
    pipe row(-1);
  else
    v_new_str:=v_str;
    while 1=1 loop
      if instr(v_new_str,v_split)=0 then
        pipe row(v_new_str);
        exit;
      else
        pipe row(substr(v_new_str,1,instr(v_new_str,v_split)-1));
        v_new_str:=substr(v_new_str,instr(v_new_str,v_split)+1);
      end if;
    end loop;
  end if;
  return;
end;
/

