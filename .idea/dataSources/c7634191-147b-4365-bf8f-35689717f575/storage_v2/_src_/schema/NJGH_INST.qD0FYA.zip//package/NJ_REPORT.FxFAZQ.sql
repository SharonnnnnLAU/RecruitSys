create package NJ_REPORT is

  -- Author  : XUYF
  -- Created : 2018/05/25 18:00:01
  -- Purpose : 打印报表

  type rq_cursor is ref cursor;
  type str_table is table of varchar2(1000);
  type num_table is table of number(8,2);
  type str_list is varray(1000) of varchar2(100);
  type tab_list is table of varchar2(1000) not null;

  -- 测试
  procedure Test(rzttable out rq_cursor,v_pid in integer);


  --分隔形成子表
  function Split(str in varchar2, delimiter varchar2) return str_table;

  --计算行编号
  function CalcRowNum(cnt in integer,valueTab in out num_table,rowNum in integer,hasRow out boolean) return num_table;

  --全要素章节编号值 - 全部0、仅建筑1、仅市政2
  procedure GetNumOfQYS(numtable out rq_cursor,v_pid in integer,jzOrSZ in integer);

  --修正数值转换字符串加上0
  function FixNum(num in number) return varchar2;



end NJ_REPORT;
/

