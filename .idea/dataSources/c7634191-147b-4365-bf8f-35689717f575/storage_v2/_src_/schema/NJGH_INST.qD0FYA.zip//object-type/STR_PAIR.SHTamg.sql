create TYPE "STR_PAIR"                                                                          as object
(
  -- Author  : XUYF
  -- Created : 2018/5/31 18:03:19
  -- Purpose :

  -- Attributes
  F1 varchar(1000),
  F2 varchar(1000)
)
/

