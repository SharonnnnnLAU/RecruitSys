create package PHGL_JZBYX is

 type r_cursor is ref cursor;
  type str_table is table of varchar2(1000);
    --????
  procedure fzxk(rzttable  out r_cursor,
                startdate in date,
                enddate   in date,
                v_q       in varchar,
                v_gdlx    in varchar,
                v_bm in varchar,
                v_ry in varchar,
                v_fl in varchar,
                v_xj       in varchar,
                v_yqbm     in varchar,
                noshowdata in integer);

  --????
  procedure jzbyx(rzttable  out r_cursor,
                startdate in date,
                enddate   in date,
                v_q       in varchar,
                v_gdlx    in varchar,
                v_bm in varchar,
                v_ry in varchar,
                v_fl in varchar,
                v_xj       in varchar,
                v_yqbm     in varchar,
                noshowdata in integer);
--????
  procedure tjqd(rzttable  out r_cursor,
                startdate in date,
                enddate   in date,
                v_q       in varchar,
                v_gdlx    in varchar,
                v_bm in varchar,
                v_ry in varchar,
                v_fl in varchar,
                --v_xj       in varchar,
                v_yqbm     in varchar,
                noshowdata in integer);

end PHGL_JZBYX;

/

