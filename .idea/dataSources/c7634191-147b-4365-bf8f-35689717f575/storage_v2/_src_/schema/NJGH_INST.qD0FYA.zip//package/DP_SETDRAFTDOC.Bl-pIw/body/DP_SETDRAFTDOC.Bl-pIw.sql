create package body DP_setDraftDoc is

  --setDoc用地业务：局长审批环节设置拟稿纸bz_doc
  procedure setYdDoc(v_pid in integer) is
    v_cid            integer;
    v_baseId         integer;
    v_zbactivityname varchar(500);
    v_zbbm           varchar(500);
    v_hbbm           varchar(1000);
    v_zbng           varchar(500);
    v_hbng           varchar(1000);
    v_zbhg           varchar(500);
    v_hbhg           varchar(1000);
    v_jnlq           varchar(1000);
    v_projectname    varchar(4000);
    v_businessId     integer;
    v_countDoc       integer;
    v_doctitle       varchar(2000);
  begin
    select t.fk_business_id
      into v_businessId
      from pcc_project t
     where t.id = v_pid;
    if v_businessId is null or v_businessId != 61 then
      return;
    end if;
    v_jnlq := 'FJ玄武,FJ鼓楼,FJ建邺,FJ秦淮,FJ栖霞,FJ雨花台';
    for i in (select t.id,
                     s.linename,
                     c.projectname,
                     decode(g2.id, 1007309, g1.shortname, g2.shortname) as shortname,
                     decode(g2.id, 1007309, g1.orgcode, g2.orgcode) as orgcode,
                     s.activityname,
                     s.loginname,
                     s.username,
                     s.unitname,
                     s.taskid
                from pcc_project t
                left join bz_caseinstrelation n
                  on n.pid = t.id
                left join bz_projectcase c
                  on c.id = n.cid
                left join pcc_specialsendconfig s
                  on t.id = s.pid
                left join njgh_sec.dcc_org g1
                  on s.unitid = g1.id
                left join njgh_sec.dcc_org g2
                  on g1.parentid = g2.id
               where 1 = 1
                 and t.lifestate = '正常'
                 and s.taskid is not null
                 and s.activityname in
                     ('办理', '审核', '会签', '会办办理', '会办审核')
                    --and t.fk_business_id = 61
                 and t.id = v_pid
               order by t.id,
                        s.linename,
                        decode(g2.id, 1007309, g1.shortname, g2.shortname) desc) loop
      if v_projectname is null then
        v_projectname := i.projectname;
      end if;
      if instr(v_jnlq, i.orgcode) > 0 then
        if v_zbactivityname is null then
          if '办理' = i.activityname then
            v_zbactivityname := i.activityname;
            v_zbbm           := i.shortname;
            v_zbng           := i.username;
          elsif '审核' = i.activityname then
            v_zbbm           := i.shortname;
            v_zbactivityname := i.activityname;
            v_zbhg           := i.username;
          elsif '会办办理' = i.activityname then
            v_zbbm           := i.shortname;
            v_zbactivityname := i.activityname;
            v_zbng           := i.username;
          elsif '会办审核' = i.activityname then
            v_zbbm           := i.shortname;
            v_zbactivityname := i.activityname;
            v_zbhg           := i.username;
          else
            if v_hbbm is null then
              v_hbbm := i.shortname;
              v_hbhg := i.username;
            else
              if instr(v_hbbm, i.shortname) = 0 then
                v_hbbm := v_hbbm || ',' || i.shortname;
              end if;
              if instr(v_hbhg, i.username) = 0 then
                v_hbhg := v_hbhg || ',' || i.username;
              end if;
            end if;
          end if;
        else
          if instr('办理,审核', v_zbactivityname) > 0 then
            if '审核' = i.activityname then
              if v_zbhg is null then
                v_zbhg := i.username;
              elsif instr(v_zbhg, i.username) = 0 then
                v_zbhg := v_zbhg || ',' || i.username;
              end if;
            elsif '办理' = i.activityname then
              if v_zbng is null then
                v_zbng := i.username;
              elsif instr(v_zbng, i.username) = 0 then
                v_zbng := v_zbng || ',' || i.username;
              end if;
            elsif '会签' = i.activityname then
              if v_hbbm is null then
                v_hbbm := i.shortname;
                v_hbhg := i.username;
              else
                if instr(v_hbbm, i.shortname) = 0 then
                  v_hbbm := v_hbbm || ',' || i.shortname;
                end if;
                if instr(v_hbhg, i.username) = 0 then
                  v_hbhg := v_hbhg || ',' || i.username;
                end if;
              end if;
            end if;
          elsif instr('会办办理,会办审核', v_zbactivityname) > 0 then
            if '会办审核' = i.activityname then
              if v_zbhg is null then
                v_zbhg := i.username;
              elsif instr(v_zbhg, i.username) = 0 then
                v_zbhg := v_zbhg || ',' || i.username;
              end if;
            elsif '会办办理' = i.activityname then
              if v_zbng is null then
                v_zbng := i.username;
              elsif instr(v_zbng, i.username) = 0 then
                v_zbng := v_zbng || ',' || i.username;
              end if;
            elsif '会签' = i.activityname then
              if v_hbbm is null then
                v_hbbm := i.shortname;
                v_hbhg := i.username;
              else
                if instr(v_hbbm, i.shortname) = 0 then
                  v_hbbm := v_hbbm || ',' || i.shortname;
                end if;
                if instr(v_hbhg, i.username) = 0 then
                  v_hbhg := v_hbhg || ',' || i.username;
                end if;
              end if;
            end if;
          end if;
        end if;
      else
        if '会签' = i.activityname then
          if v_hbbm is null then
            v_hbbm := i.shortname;
            v_hbhg := i.username;
          else
            if instr(v_hbbm, i.shortname) = 0 then
              v_hbbm := v_hbbm || ',' || i.shortname;
            end if;
            if instr(v_hbhg, i.username) = 0 then
              v_hbhg := v_hbhg || ',' || i.username;
            end if;
          end if;
        end if;
      end if;
    end loop;
    --设doc--BZ_DOC拟稿纸
    if 61 = v_businessId then
      --用地业务
      for j in (select b.cid from bz_caseinstrelation b where b.pid = v_pid) loop
        select count(*) into v_countDoc from bz_doc d where d.cid = j.cid;
        if v_countDoc = 0 then
          insert into bz_doc
            (id, cid, doctitle, zbbm, zbng, zbhg, hbbm, hbng, hbhg)
          values
            (s_bz_doc.nextval,
             j.cid,
             v_projectname,
             v_zbbm,
             v_zbng,
             v_zbhg,
             v_hbbm,
             v_hbng,
             v_hbhg);
        else
          select d.doctitle
            into v_doctitle
            from bz_doc d
           where d.cid = j.cid;
          if v_doctitle is null then
            update bz_doc d
               set d.doctitle = v_projectname,
                   zbbm       = v_zbbm,
                   zbng       = v_zbng,
                   zbhg       = v_zbhg,
                   hbbm       = v_hbbm,
                   hbng       = v_hbng,
                   hbhg       = v_hbhg
             where d.cid = j.cid;
          else
            update bz_doc d
               set zbbm = v_zbbm,
                   zbng = v_zbng,
                   zbhg = v_zbhg,
                   hbbm = v_hbbm,
                   hbng = v_hbng,
                   hbhg = v_hbhg
             where d.cid = j.cid;
          end if;
        end if;
      end loop;
      commit;
    end if;
  end;
  
  --供地业务：局长审批环节设置拟稿纸bz_doc
  procedure setGdProjectDoc(v_pid in integer) is
    v_zbbm           varchar(500);
    v_zbng           varchar(500);
    v_zbhg           varchar(500);
    v_hbUser         varchar(500);
    v_jnlq           varchar(500);
    v_jnjq           varchar(500);
    v_xsq            varchar(500);
    v_projectname    varchar(4000);
    v_businessId     integer;
    v_processname    varchar(500);
    v_businessProcessId     integer;
    v_countDoc       integer;
    v_doctitle       varchar(2000);
    v_tdcrmj         number(14,2);
    v_gpqsj          number(14,2); 
  begin
    v_jnlq := 'FJ玄武,FJ鼓楼,FJ建邺,FJ秦淮,FJ栖霞,FJ雨花台';
    v_jnjq := 'FJ玄武,FJ鼓楼,FJ建邺,FJ秦淮,FJ栖霞,FJ雨花台,FJ浦口,FJ六合,FJ江宁';
    v_xsq := 'FJ高淳,FJ溧水,J江北新区';
    select t.fk_business_id,s.processname
      into v_businessId,v_processname
      from pcc_project t
      left join njgh_dap.dap_businessprocess b on b.id = t.businessprocessid
      left join njgh_dap.dcc_process s on s.id = b.fk_process_id
     where t.id = v_pid;
    --506经营性招拍挂供地方案及挂牌文件、528工业招拍挂供地方案及挂牌文件、526协议出让审批、527改变用地条件补办出让
    if (v_businessId = 483 or v_businessId = 523) and v_processname not like '%挂牌%' then
       return;
    end if;
    select td.tdcrmj, cb.gpqsj into v_tdcrmj,v_gpqsj
      from pcc_project t
      left join bz_caseinstrelation n on n.pid = t.id
      left join bz_projectcase c on c.id = n.cid
      left join bz_gd_gkcr_tdxx td on td.cid = c.id
      left join bz_gd_gkcr_cbpfxx cb on cb.cid = c.id
          where t.id = v_pid;
    for i in (select t.id,
                     s.linename,
                     c.projectname,
                     decode(g2.id, 1007309, g1.shortname, g2.shortname) as shortname,
                     decode(g2.id, 1007309, g1.orgcode, g2.orgcode) as orgcode,
                     s.activityname,
                     s.loginname,
                     s.username,
                     s.unitname,
                     s.taskid
                from pcc_project t
                left join bz_caseinstrelation n
                  on n.pid = t.id
                left join bz_projectcase c
                  on c.id = n.cid
                left join pcc_specialsendconfig s
                  on t.id = s.pid
                left join njgh_sec.dcc_org g1
                  on s.unitid = g1.id
                left join njgh_sec.dcc_org g2
                  on g1.parentid = g2.id  
               where 1 = 1
                 and t.lifestate = '正常'
                 and s.taskid is not null
                 and s.activityname in
                     ('办理', '审核','审批')
                 and t.id = v_pid
               order by t.id,
                        s.linename,
                        decode(g2.id, 1007309, g1.shortname, g2.shortname) desc,
                        s.taskid) loop
      if v_projectname is null then
        v_projectname := i.projectname;
      end if;
      if v_businessProcessId = 506 then
         if (instr(v_jnjq, i.orgcode) > 0) or (instr(v_xsq, i.orgcode) > 0 and (v_tdcrmj > (2/3)*150*1000 or v_gpqsj > 200000)) then
            if '办理' = i.activityname then
              if v_zbbm is null then
                v_zbbm           := i.shortname;
              else
                if instr(v_zbbm, i.shortname) = 0 then
                  v_zbbm := v_zbbm || ',' || i.shortname;
                end if;                
              end if;
              if  v_zbng is null then
                  v_zbng           := i.username;
              elsif instr(v_zbng, i.username) = 0 then
                  v_zbng := v_zbng || ',' || i.username;
              end if;            
            elsif '审核' = i.activityname then
              if v_zbbm is null then
                 v_zbbm           := i.shortname;
              else
                if instr(v_zbbm, i.shortname) = 0 then
                  v_zbbm := v_zbbm || ',' || i.shortname;
                end if;
              end if; 
              if v_zbhg is null then
                 v_zbhg           := i.username;              
              elsif instr(v_zbhg, i.username) = 0 then
                  v_zbhg := v_zbhg || ',' || i.username;
              end if;
            end if;  
         end if; 
      else
        if '办理' = i.activityname then
          if v_zbbm is null then
            v_zbbm           := i.shortname;
          else
            if instr(v_zbbm, i.shortname) = 0 then
              v_zbbm := v_zbbm || ',' || i.shortname;
            end if;                
          end if;
          if  v_zbng is null then
              v_zbng           := i.username;
          elsif instr(v_zbng, i.username) = 0 then
              v_zbng := v_zbng || ',' || i.username;
          end if;            
        elsif '审核' = i.activityname then
          if v_zbbm is null then
             v_zbbm           := i.shortname;
          else
            if instr(v_zbbm, i.shortname) = 0 then
              v_zbbm := v_zbbm || ',' || i.shortname;
            end if;
          end if; 
          if v_zbhg is null then
             v_zbhg           := i.username;              
          elsif instr(v_zbhg, i.username) = 0 then
              v_zbhg := v_zbhg || ',' || i.username;
          end if;
        end if;  
      end if;
      if '审批' = i.activityname then
          if v_hbUser is null then
            v_hbUser := i.username;
          else
            if instr(v_hbUser, i.username) = 0 then
              v_hbUser := v_hbUser || ',' || i.username;
            end if;
          end if;          
      end if;
    end loop;
    --设doc--BZ_DOC拟稿纸
    if v_zbbm is not null or v_zbng is not null or v_zbhg is not null then
      --用地业务
      for j in (select b.cid from bz_caseinstrelation b where b.pid = v_pid) loop
        select count(*) into v_countDoc from bz_doc d where d.cid = j.cid;
        if v_countDoc = 0 then
          insert into bz_doc
            (id, cid, doctitle, zbbm, zbng, zbhg, hbbm)
          values
            (s_bz_doc.nextval,
             j.cid,
             v_projectname,
             v_zbbm,
             v_zbng,
             v_zbhg,
             v_hbUser);
        else
          select d.doctitle
            into v_doctitle
            from bz_doc d
           where d.cid = j.cid;
          if v_doctitle is null then
            update bz_doc d
               set d.doctitle = v_projectname,
                   zbbm       = v_zbbm,
                   zbng       = v_zbng,
                   zbhg       = v_zbhg,
                   hbbm       = v_hbUser
             where d.cid = j.cid;
          else
            update bz_doc d
               set zbbm = v_zbbm,
                   zbng = v_zbng,
                   zbhg = v_zbhg,
                   hbbm = v_hbUser
             where d.cid = j.cid;
          end if;
        end if;
      end loop;
      commit;
    end if;
  end;

end DP_setDraftDoc;
/

