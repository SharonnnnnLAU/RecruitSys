create package body DP_copydata is
      ---复制选址用地审批信息
    procedure copyXzYdSpxx(v_cid1 in integer,v_cid2 in integer)  is

      begin
        --申报材料
     delete bz_sbcl b where b.cid = v_cid1;
     insert into bz_sbcl
        (id, cid, clmc, clxs, clfs, xh, bb, wh, zzyq, sdfs, dzwj, qj, ygsm, ys, dzwjm, bdw, txr, qsr, cllb, qjjr, thfs, xgfz)
        select s_bz_sbcl.nextval, v_cid1, clmc, clxs, clfs, xh, bb, wh, zzyq, sdfs, dzwj, qj, ygsm, ys, dzwjm, bdw, txr, qsr, cllb, qjjr, thfs, xgfz from bz_sbcl  b  where  b.cid=v_cid2;
    commit;
       --选址用地核心数据
    delete BZ_XZYD b where b.cid = v_cid1;
    insert into bz_xzyd
      (id, cid, sfgs, jsdd, xzsy, xzwz, jsydmjhj, dzydmjhj, dkzmj, qtsm, xzsy_qt, zhmshj, sfcjax, sfhwbtj, sfcbyd)
    select s_bz_xzyd.nextval, v_cid1, sfgs, jsdd, xzsy, xzwz, jsydmjhj, dzydmjhj, dkzmj, qtsm, xzsy_qt, zhmshj, sfcjax, sfhwbtj, sfcbyd from bz_xzyd  b  where  b.cid=v_cid2;
    commit;

        --代征用地地块明细
    delete BZ_YD_DZ_DKMX b where b.cid = v_cid1;
    delete BZ_YD_DZ_XZMX b where b.cid = v_cid1;

    for  i  in (
      select s_bz_yd_dz_dkmx.nextval  newid, id, cid, dkid, dkmc, dkydxz, ljlmin, ljlmax, ljlsign, jzmdmin, jzmdmax, jzmdsign, ldlmin, ldlmax, ldlsign, jzxgmin, jzxgmax, jzxgsign, zhms, dkydmj
       from bz_yd_dz_dkmx  b where  b.cid=v_cid2
      )loop
      insert into bz_yd_dz_dkmx
        (id, cid, dkid, dkmc, dkydxz, ljlmin, ljlmax, ljlsign, jzmdmin, jzmdmax, jzmdsign, ldlmin, ldlmax, ldlsign, jzxgmin, jzxgmax, jzxgsign, zhms, dkydmj)
      values
        (i.newid, v_cid1, i.dkid, i.dkmc, i.dkydxz, i.ljlmin, i.ljlmax, i.ljlsign, i.jzmdmin, i.jzmdmax, i.jzmdsign, i.ldlmin, i.ldlmax, i.ldlsign, i.jzxgmin, i.jzxgmax, i.jzxgsign, i.zhms, i.dkydmj);
       --代征用地性质明细
       insert into bz_yd_dz_xzmx
      (id, ydxz, bl, mj, dkbh, cid, ref_bz_yd_dz_dkmx_id)
   select s_bz_yd_dz_xzmx.nextval, ydxz, bl, mj, dkbh, v_cid1, i.newid from bz_yd_dz_xzmx  b  where  b.ref_bz_yd_dz_dkmx_id=i.id;
      commit;
    end loop;

        --建设用地地块明细
 delete bz_yd_js_dkmx b where b.cid = v_cid1;
   delete bz_yd_js_xzmx b where b.cid = v_cid1;
  for i  in  (
     select s_BZ_YD_JS_DKMX.Nextval as  newid ,id,  cid, dkid, dkmc, dkydxz, ljlmin, ljlmax, ljlsign, jzmdmin, jzmdmax, jzmdsign, ldlmin, ldlmax, ldlsign, jzxgmin, jzxgmax, jzxgsign, jzldx, jzldfh, fh, zhms, dkydmj
   from bz_yd_js_dkmx  b  where  b.cid=v_cid2
    )loop
    insert into bz_yd_js_dkmx
      (id, cid, dkid, dkmc, dkydxz, ljlmin, ljlmax, ljlsign, jzmdmin, jzmdmax, jzmdsign, ldlmin, ldlmax, ldlsign, jzxgmin, jzxgmax, jzxgsign, jzldx, jzldfh, fh, zhms, dkydmj)
    values
      (i.newid, v_cid1, i.dkid, i.dkmc, i.dkydxz, i.ljlmin, i.ljlmax, i.ljlsign, i.jzmdmin, i.jzmdmax, i.jzmdsign, i.ldlmin, i.ldlmax, i.ldlsign, i.jzxgmin, i.jzxgmax, i.jzxgsign, i.jzldx, i.jzldfh, i.fh, i.zhms, i.dkydmj);
      --建设用地性质明细
       insert into bz_yd_js_xzmx
      (id, ydxz, bl, mj, dkbh, cid, ref_bz_yd_js_dkmx_id)
  select s_bz_yd_js_xzmx.nextval, ydxz, bl, mj, dkbh, v_cid1, i.newid from bz_yd_js_xzmx  b where  b.ref_bz_yd_js_dkmx_id =i.id;
      commit;
  end loop;

  end;

  ---复制规划条件审批信息
    procedure copyGhtjSpxx(v_cid1 in integer,v_cid2 in integer) is
     begin
       --方案工程_市政指标
         delete BZ_FAGC_SZZB b where b.cid = v_cid1;
      insert into bz_fagc_szzb
        (id, cid, szmc, sglx, zjgj, kd, sxjdcds, ks, hdmxs, bjdmk, tgxs, gs, ccab, dldy, dmgk, dj, szlxdl, cd, sl)
   select s_BZ_FAGC_SZZB.Nextval, v_cid1, szmc, sglx, zjgj, kd, sxjdcds, ks, hdmxs, bjdmk, tgxs, gs, ccab, dldy, dmgk, dj, szlxdl, cd, sl from bz_fagc_szzb  b where  b.cid=v_cid2;
   commit;
          --条件_建筑规划要求
         delete BZ_GHTJ_JZGHYQ b where b.cid = v_cid1;
         insert into bz_ghtj_jzghyq
           (id, gl_hxsbnrqt, gl_aztyn, gl_fazx, gl_qtyq, bz_scrtj, bz_tjyxq, cid, ghgy, zb_btxsm, zb_gjpt_jssx, zb_gjpt_xq, zb_gjpt_yzfwsmj, zb_gjpt_fjjz, zb_gjpt_fjjzgs, zb_gjpt, zb_tcpjlx, zb_tcpj,
           zb_zbsm_mjjs, zb_zbsm_jzgdjs, zb_zbsm, zb_sfzz, zb_hxbl, zb_jtzz, yq_dkcssj, yq_dkcssjfj, yq_jjtr, yq_styx, yq_stex, yq_styqys, yq_stxj, yq_stzz, yq_stbg, yq_styy, yq_stqt, yq_styq, yq_qt_ld,
            yq_qt_yt, yq_qtyq, gl_bstj1, gl_bstj2, gl_bmyjhxyw1, gl_bmyjjtbm1, gl_bmyjqtbm1, gl_bmyjhxyw2, gl_bmyjjtbm2, gl_bmyjqtbm2, gl_bmyjhxyw3, gl_bmyjjtbm3, gl_bmyjqtbm3, gl_fasjdwgs, gl_faxsgs, gl_hxsbsx,
             gl_hxsbnr, gl_bmyj_qt, ghzb_ggpj, ghzb_tcpj, ghzb_zbsm, ghyq_jtzz, ghyq_jjtr, ghyq_styq, ghyq_qtyq, bsyq_bstj, bsyq_bmyj, bsyq_qtyq, zb_tcpjlxsm, sfhwbtj, sfcjax, sfcbyd)
       select s_BZ_GHTJ_JZGHYQ.Nextval, gl_hxsbnrqt, gl_aztyn, gl_fazx, gl_qtyq, bz_scrtj, bz_tjyxq, v_cid1, ghgy, zb_btxsm, zb_gjpt_jssx, zb_gjpt_xq, zb_gjpt_yzfwsmj, zb_gjpt_fjjz, zb_gjpt_fjjzgs, zb_gjpt, zb_tcpjlx, zb_tcpj,
        zb_zbsm_mjjs, zb_zbsm_jzgdjs, zb_zbsm, zb_sfzz, zb_hxbl, zb_jtzz, yq_dkcssj, yq_dkcssjfj, yq_jjtr, yq_styx, yq_stex, yq_styqys, yq_stxj, yq_stzz, yq_stbg, yq_styy, yq_stqt, yq_styq, yq_qt_ld,
         yq_qt_yt, yq_qtyq, gl_bstj1, gl_bstj2, gl_bmyjhxyw1, gl_bmyjjtbm1, gl_bmyjqtbm1, gl_bmyjhxyw2, gl_bmyjjtbm2, gl_bmyjqtbm2, gl_bmyjhxyw3, gl_bmyjjtbm3, gl_bmyjqtbm3, gl_fasjdwgs, gl_faxsgs, gl_hxsbsx,
         gl_hxsbnr, gl_bmyj_qt, ghzb_ggpj, ghzb_tcpj, ghzb_zbsm, ghyq_jtzz, ghyq_jjtr, ghyq_styq,ghyq_qtyq, bsyq_bstj, bsyq_bmyj, bsyq_qtyq, zb_tcpjlxsm, sfhwbtj, sfcjax, sfcbyd
          from bz_ghtj_jzghyq   b  where  b.cid=v_cid2;
          commit;
           --条件_建筑全要素1
         delete BZ_GHTJ_JZQYS1 b where b.cid = v_cid1;
         insert into bz_ghtj_jzqys1
           (id, cid, hjzyd, dzx, dzb, dzd, dzn, gy_wz, gy_gntz, gy_zb_dkgyx, gy_zb_tlfw, gy_zb_tlqk, gy_zb_gdfw, gy_zb_gdqk, gy_zb_dkfwgh, gy_zb_dkxzss,
            gy_ydmj_zyd, gy_ydmj_kjmj, gy_ydmj_dk, gy_ydmj_dkmj, gy_ydmj_dksf, gy_ydmj_dksfmj, gy_ydmj_dkxf, gy_ydmj_dkxfmj, gy_ydmj_dzld,
            gy_ydmj_dzhd, gy_ydmj_dzdl, gy_ydmj_szss, gy_ydmj_dzyq, ydzb_ydmj, ydzb_gsfw, ydzb_hhbl, ydzb_hh_ydxz, ydzb_hh_hhyd, ydzb_hh_jzmj,
             ydzb_hh_blx, ydzb_hh_bld, ydzb_sz_dk, ydzb_sz_blx, ydzb_sz_bld, ydzb_sb_bl, ydzb_sypt, ydzb_sypt_dk, ydzb_sypt_bl, ydzb_jdsgypj,
             ydzb_jdsgypj_bl, ydzb_ddxkj, ydzb_ddxkj_dk, ydzb_ddxkj_ftsd, ydzb_ddxkj_gn, ydzb_ddxkj_cm, ydzb_ddxtd, ydzb_ddxtd_ftsd, ydzb_ddxtd_dk1,
             ydzb_ddxtd_dk2, ydzb_ddxtd_tds, ydzb_ddxtd_dk3, ydzb_ddxtd_tdkd, ydzb_ddxtd_cm, ydzb_ddskj, ydzb_ddskj_dk, ydzb_ddskj_gn, ydzb_ddskj_dbjl,
              ydzb_ddskj_jg, ydzb_ddskj_rjldk, ydzb_dkzll, ydzb_dkzll_dk1, ydzb_dkzll_dk2, ydzb_dkzll_jc, ydzb_dkzll_dk3, ydzb_dkzll_kd, ydzb_dkzll_dbjl,
               ydzb_dkzll_jg, ydzb_dkzll_rjldk, ydzb_jzgd, ydzb_jzgd_jzwzgd, ydzb_jzgd_gzwzgd, ydzb_jzgd_bzk, ydzb_jzgd_neqd, ydzb_jzgd_wm,
                ydzb_jzmj, ydzb_zbbtxsm, ptss_zt_ptyq, ptss_zt_jssx, ptss_zt_yzyq, ptss_ggld, ptss_ggld_xjzq, ptss_ggld_jgjq, ptss_js, ptss_js_zxyd,
                 ptss_js_yyydgm, ptss_js_yyjzmj, ptss_jz_sqwsydgm, ptss_jz_sqwsjzmj, ptss_jz_jjyljzmj, ptss_jz_lnzljzmj, ptss_jz_sqylyjzmj, ptss_jz_sqylycw,
                  ptss_jz_zhfwydgm, ptss_jz_zhfwjzmj, ptss_jz_whhdjzmj, ptss_jz_tyhdjzmj, ptss_jz_tyhdsyy, ptss_jz_jzgljzmj, ptss_jz_sqfwjzmj, ptss_jz_pcsydgm,
                   ptss_jz_pcsjzmj, ptss_jz_yeyjzmj, ptss_jz_cscjzmj, ptss_jz_yzjzmj, ptss_jz_jdtcydgm, ptss_jz_gcjzmj, ptss_jz_sqgyydgm, ptss_jc, ptss_jcyd,
                   ptss_jc_wsfwjzmj, ptss_jc_whhdjzmj, ptss_jc_tyhdjzmj, ptss_jc_tyhdlyy, ptss_jc_jcsqjzmj, ptss_jc_sqjwjzmj, ptss_jc_jjyljzmj, ptss_jc_gcjzmj, ptss_jc_yyydgm,
                    ptss_ylss, ptss_yl_mbhmj, ptss_wyfwyf, ptss_ljsjd, ptss_kjfwyf, ptss_xbx, ptss_jyjq, ptss_gc, ptss_my, ptss_mysymj, ptss_wza, ptss_sz_ydjz, ptss_sz_rfjbq,
                     ptss_sz_shtcc, ptss_sz_zxctf, ptss_sz_zxctfcrk, wb_yzyq, wb_yzyq_jq, wb_yzyq_fmq, wb_yzyq_lsdd, wb_yzyq_whmz, wb_yzyq_whmc, wb_yzyq_dxwwzdbhq, wb_yzyq_wwbhdw,
                      wb_yzyq_bkydww, wb_yzyq_lsjz, wb_yzyq_zyjxdjz, wb_yzyq_ghkzjz, wb_yzyq_gsmm, wb_xdyq, wb_falzcxyq, wb_flcy_wbdw, wb_flcy_lswhjq, wb_flcy_lsfmq, wb_flcy_mzc, wb_flcy_lsjz,
                       wb_flcy_fjmsq, wb_flcy_msq, wb_flcy_dxzyyjyz, wb_flcy_whmc, wb_gsmm, wb_kgktyq, wb_kgktyq_wbqn, wb_kgktyq_cwwpm, wb_kgktyq_cryd, wb_kgktyq_hbyyd)

         select s_BZ_GHTJ_JZQYS1.Nextval, v_cid1, hjzyd, dzx, dzb, dzd, dzn, gy_wz, gy_gntz, gy_zb_dkgyx, gy_zb_tlfw, gy_zb_tlqk, gy_zb_gdfw, gy_zb_gdqk, gy_zb_dkfwgh, gy_zb_dkxzss, gy_ydmj_zyd, gy_ydmj_kjmj,
          gy_ydmj_dk, gy_ydmj_dkmj, gy_ydmj_dksf, gy_ydmj_dksfmj, gy_ydmj_dkxf, gy_ydmj_dkxfmj, gy_ydmj_dzld, gy_ydmj_dzhd, gy_ydmj_dzdl, gy_ydmj_szss, gy_ydmj_dzyq, ydzb_ydmj, ydzb_gsfw,
           ydzb_hhbl, ydzb_hh_ydxz, ydzb_hh_hhyd, ydzb_hh_jzmj, ydzb_hh_blx, ydzb_hh_bld, ydzb_sz_dk, ydzb_sz_blx, ydzb_sz_bld, ydzb_sb_bl, ydzb_sypt, ydzb_sypt_dk, ydzb_sypt_bl, ydzb_jdsgypj,
            ydzb_jdsgypj_bl, ydzb_ddxkj, ydzb_ddxkj_dk, ydzb_ddxkj_ftsd, ydzb_ddxkj_gn, ydzb_ddxkj_cm, ydzb_ddxtd, ydzb_ddxtd_ftsd, ydzb_ddxtd_dk1, ydzb_ddxtd_dk2, ydzb_ddxtd_tds, ydzb_ddxtd_dk3,
             ydzb_ddxtd_tdkd, ydzb_ddxtd_cm, ydzb_ddskj, ydzb_ddskj_dk, ydzb_ddskj_gn, ydzb_ddskj_dbjl, ydzb_ddskj_jg, ydzb_ddskj_rjldk, ydzb_dkzll, ydzb_dkzll_dk1, ydzb_dkzll_dk2, ydzb_dkzll_jc,
              ydzb_dkzll_dk3, ydzb_dkzll_kd, ydzb_dkzll_dbjl, ydzb_dkzll_jg, ydzb_dkzll_rjldk, ydzb_jzgd, ydzb_jzgd_jzwzgd, ydzb_jzgd_gzwzgd, ydzb_jzgd_bzk, ydzb_jzgd_neqd, ydzb_jzgd_wm, ydzb_jzmj,
               ydzb_zbbtxsm, ptss_zt_ptyq, ptss_zt_jssx, ptss_zt_yzyq, ptss_ggld, ptss_ggld_xjzq, ptss_ggld_jgjq, ptss_js, ptss_js_zxyd, ptss_js_yyydgm, ptss_js_yyjzmj, ptss_jz_sqwsydgm, ptss_jz_sqwsjzmj,
                ptss_jz_jjyljzmj, ptss_jz_lnzljzmj, ptss_jz_sqylyjzmj, ptss_jz_sqylycw, ptss_jz_zhfwydgm, ptss_jz_zhfwjzmj, ptss_jz_whhdjzmj, ptss_jz_tyhdjzmj, ptss_jz_tyhdsyy, ptss_jz_jzgljzmj, ptss_jz_sqfwjzmj,
                ptss_jz_pcsydgm, ptss_jz_pcsjzmj, ptss_jz_yeyjzmj, ptss_jz_cscjzmj, ptss_jz_yzjzmj, ptss_jz_jdtcydgm, ptss_jz_gcjzmj, ptss_jz_sqgyydgm, ptss_jc, ptss_jcyd, ptss_jc_wsfwjzmj, ptss_jc_whhdjzmj,
                 ptss_jc_tyhdjzmj, ptss_jc_tyhdlyy, ptss_jc_jcsqjzmj, ptss_jc_sqjwjzmj, ptss_jc_jjyljzmj, ptss_jc_gcjzmj, ptss_jc_yyydgm, ptss_ylss, ptss_yl_mbhmj, ptss_wyfwyf, ptss_ljsjd, ptss_kjfwyf, ptss_xbx,
                 ptss_jyjq, ptss_gc, ptss_my, ptss_mysymj, ptss_wza, ptss_sz_ydjz, ptss_sz_rfjbq, ptss_sz_shtcc, ptss_sz_zxctf, ptss_sz_zxctfcrk, wb_yzyq, wb_yzyq_jq, wb_yzyq_fmq, wb_yzyq_lsdd, wb_yzyq_whmz,
                  wb_yzyq_whmc, wb_yzyq_dxwwzdbhq, wb_yzyq_wwbhdw, wb_yzyq_bkydww, wb_yzyq_lsjz, wb_yzyq_zyjxdjz, wb_yzyq_ghkzjz, wb_yzyq_gsmm, wb_xdyq, wb_falzcxyq, wb_flcy_wbdw, wb_flcy_lswhjq, wb_flcy_lsfmq,
                  wb_flcy_mzc, wb_flcy_lsjz, wb_flcy_fjmsq, wb_flcy_msq, wb_flcy_dxzyyjyz, wb_flcy_whmc, wb_gsmm, wb_kgktyq, wb_kgktyq_wbqn, wb_kgktyq_cwwpm, wb_kgktyq_cryd, wb_kgktyq_hbyyd from bz_ghtj_jzqys1 b
                  where  b.cid=v_cid2;
          commit;
           --条件_建筑全要素2
         delete BZ_GHTJ_JZQYS2 b where b.cid = v_cid1;
         insert into bz_ghtj_jzqys2
           (id, cid, jtyq_tcpj_yzyq, jtyq_tcpj_xgyq, jtyq_cdss, jtyq_cdss_bcw, jtyq_cdss_gjcdz, jtyq_cdss_czqccdz, jtyq_cdss_jzcdz, jtyq_cdss_qtcdz, jtyq_cdss_qtcdzbl, jtyq_crk_wz, jtyq_crk_yq1, jtyq_crk_yq2,
            jtyq_crk_yq3, jtyq_crk_sz, jtyq_crk_tryq, jtyq_crk_dxsc, jtyq_crk_pdcd, jtyq_dk_tdyq, jtyq_dk_tyyey, jtyq_dk_tyxx, jtyq_dk_tyzx, jtyq_dk_tyqt, jtyq_dk_rckhfl, jtyq_dk_ggjtxjyq, jtyq_dk_qtyq,
             cssjyq_zt_yzyq, cssjyq_zt_tzyq, cssjyq_kjxt_jzht, cssjyq_kjxt_jqkz, cssjyq_kjxt_jmlx, cssjyq_kjxt_wqsz, cssjyq_kjxt_kckjyq, dxkjyq_sycs, dxkjyq_fcgnsz, dxkjyq_xjyq, dxkjyq_xj_dkyq, dxkjyq_xj_gdggkj,
              dxkjyq_xj_xcsgc, jzsjyq_zt, jzsjyq_dpbg_yzyq, jzsjyq_dpbg_yzgc, jzsjyq_dpbg_yzdlbg, jzsjyq_dpbg_dxsft, jzsjyq_dpbg_ftsd, jzsjyq_trgd, jzsjyq_jzjj, jzsjyq_fsss_kdbz, jzsjyq_fsss_lsss, jzsjyq_fsss_hbcs,
               jzsjyq_fsss_ggdz, jzsjyq_qtyq, ghbhyq_jq_yzyq, ghbhyq_jq_wz, ghbhyq_jq_fjq, ghbhyq_jq_fjmsq, ghbhyq_jq_slgy, ghbhyq_jq_qt1, ghbhyq_jq_qt2, ghbhyq_jq_ghyq, ghbhyq_gdjt_yzyq, ghbhyq_gdjt_bhyq,
               ghbhyq_dlxxl_yzyq, ghbhyq_hd_yzyq, ghbhyq_clbz, ghbhyq_clbz_dj, ghbhyq_clbz_lx, ghbhyq_lbss, ghbhyq_sthx, ghbhyq_qtyq_cygxaq, ghbhyq_qtyq_fqxzggx, dtstyq_zt_yzyq, dtstyq_zt_ljdj, dtstyq_zt_ljyx,
                dtstyq_zt_ljex, dtstyq_zx_yssj, dtstyq_zx_hmcs, dtstyq_zx_hmcskzl, dtstyq_zx_jzjn, dtstyq_zx_jzjnbz, dtstyq_zx_tynsb, dtstyq_zx_tynxj, dtstyq_zx_tynzz, dtstyq_zx_tynbg, dtstyq_zx_tynyy, dtstyq_zx_tynqt,
                qtghyq_pjbzf, bsyq_ztyq, bsyq_jz_fa, bsyq_jz_farf, bsyq_jz_fajzjn, bsyq_jz_fajy, bsyq_jz_fagdjt, bsyq_jz_faaj, bsyq_jz_faww, bsyq_jz_fagd, bsyq_jz_faqt, bsyq_jz_gc, bsyq_jz_gcrf, bsyq_jz_gcjzjn,
                 bsyq_jz_gcjy, bsyq_jz_gcgdjt, bsyq_jz_gcaj, bsyq_jz_gcww, bsyq_jz_gcgd, bsyq_jz_gcqt, bsyq_jz_fabx, bsyq_jz_fasjgs, bsyq_jz_faxsgs, bsyq_jz_fazx, bsyq_jz_faq, bsyq_jz_faqgs, bsyq_jz_faqtz,
                 bsyq_jz_faqhjfx, bsyq_jz_faqjtpj, bsyq_jz_faqrzfx, bsyq_jz_faqqt, bsyq_jz_gcq, bsyq_jz_gcqgs, bsyq_jz_gcqtz, bsyq_jz_gcqhjfx, bsyq_jz_gcqjtpj, bsyq_jz_gcqrzfx, bsyq_jz_gcqqt, bsyq_jz_fatj,
                 bsyq_jz_tjjzwlmt, bsyq_jz_tjyjlmt, bsyq_jz_tjygfxt, bsyq_jz_tjzxlzcg, bsyq_jz_swbj, bz_fbg_zx, bz_bgh_zx, bz_bsd_sl, bz_ghs_sj, bz_yyz_ch, bz_xmj_yq, bz_bgh_ghlm_wz, bz_bxm_md, bz_gxqyfa,
                  bz_wrtdzl, bz_bgh_zbss_wz, bz_dyycrfs, bz_hbydyytd, bz_jsdw_gzjd, bz_bgh_fzjs, fj_tjt, fj_tjtxzgx, fj_tjtxzgh, fj_tjtcssj)
              select s_bz_ghtj_jzqys2.nextval, v_cid1, jtyq_tcpj_yzyq, jtyq_tcpj_xgyq, jtyq_cdss, jtyq_cdss_bcw, jtyq_cdss_gjcdz, jtyq_cdss_czqccdz, jtyq_cdss_jzcdz, jtyq_cdss_qtcdz, jtyq_cdss_qtcdzbl, jtyq_crk_wz, jtyq_crk_yq1, jtyq_crk_yq2,
               jtyq_crk_yq3, jtyq_crk_sz, jtyq_crk_tryq, jtyq_crk_dxsc, jtyq_crk_pdcd, jtyq_dk_tdyq, jtyq_dk_tyyey, jtyq_dk_tyxx, jtyq_dk_tyzx, jtyq_dk_tyqt, jtyq_dk_rckhfl, jtyq_dk_ggjtxjyq, jtyq_dk_qtyq,
                cssjyq_zt_yzyq, cssjyq_zt_tzyq, cssjyq_kjxt_jzht, cssjyq_kjxt_jqkz, cssjyq_kjxt_jmlx, cssjyq_kjxt_wqsz, cssjyq_kjxt_kckjyq, dxkjyq_sycs, dxkjyq_fcgnsz, dxkjyq_xjyq, dxkjyq_xj_dkyq, dxkjyq_xj_gdggkj,
                 dxkjyq_xj_xcsgc, jzsjyq_zt, jzsjyq_dpbg_yzyq, jzsjyq_dpbg_yzgc, jzsjyq_dpbg_yzdlbg, jzsjyq_dpbg_dxsft, jzsjyq_dpbg_ftsd, jzsjyq_trgd, jzsjyq_jzjj, jzsjyq_fsss_kdbz, jzsjyq_fsss_lsss, jzsjyq_fsss_hbcs,
                  jzsjyq_fsss_ggdz, jzsjyq_qtyq, ghbhyq_jq_yzyq, ghbhyq_jq_wz, ghbhyq_jq_fjq, ghbhyq_jq_fjmsq, ghbhyq_jq_slgy, ghbhyq_jq_qt1, ghbhyq_jq_qt2, ghbhyq_jq_ghyq, ghbhyq_gdjt_yzyq, ghbhyq_gdjt_bhyq,
                   ghbhyq_dlxxl_yzyq, ghbhyq_hd_yzyq, ghbhyq_clbz, ghbhyq_clbz_dj, ghbhyq_clbz_lx, ghbhyq_lbss, ghbhyq_sthx, ghbhyq_qtyq_cygxaq, ghbhyq_qtyq_fqxzggx, dtstyq_zt_yzyq, dtstyq_zt_ljdj, dtstyq_zt_ljyx,
                    dtstyq_zt_ljex, dtstyq_zx_yssj, dtstyq_zx_hmcs, dtstyq_zx_hmcskzl, dtstyq_zx_jzjn, dtstyq_zx_jzjnbz, dtstyq_zx_tynsb, dtstyq_zx_tynxj, dtstyq_zx_tynzz, dtstyq_zx_tynbg, dtstyq_zx_tynyy, dtstyq_zx_tynqt,
                     qtghyq_pjbzf, bsyq_ztyq, bsyq_jz_fa, bsyq_jz_farf, bsyq_jz_fajzjn, bsyq_jz_fajy, bsyq_jz_fagdjt, bsyq_jz_faaj, bsyq_jz_faww, bsyq_jz_fagd, bsyq_jz_faqt, bsyq_jz_gc, bsyq_jz_gcrf, bsyq_jz_gcjzjn,
                      bsyq_jz_gcjy, bsyq_jz_gcgdjt, bsyq_jz_gcaj, bsyq_jz_gcww, bsyq_jz_gcgd, bsyq_jz_gcqt, bsyq_jz_fabx, bsyq_jz_fasjgs, bsyq_jz_faxsgs, bsyq_jz_fazx, bsyq_jz_faq, bsyq_jz_faqgs, bsyq_jz_faqtz,
                       bsyq_jz_faqhjfx, bsyq_jz_faqjtpj, bsyq_jz_faqrzfx, bsyq_jz_faqqt, bsyq_jz_gcq, bsyq_jz_gcqgs, bsyq_jz_gcqtz, bsyq_jz_gcqhjfx, bsyq_jz_gcqjtpj, bsyq_jz_gcqrzfx, bsyq_jz_gcqqt, bsyq_jz_fatj,
                        bsyq_jz_tjjzwlmt, bsyq_jz_tjyjlmt, bsyq_jz_tjygfxt, bsyq_jz_tjzxlzcg, bsyq_jz_swbj, bz_fbg_zx, bz_bgh_zx, bz_bsd_sl, bz_ghs_sj, bz_yyz_ch, bz_xmj_yq, bz_bgh_ghlm_wz, bz_bxm_md, bz_gxqyfa,
                        bz_wrtdzl, bz_bgh_zbss_wz, bz_dyycrfs, bz_hbydyytd, bz_jsdw_gzjd, bz_bgh_fzjs, fj_tjt, fj_tjtxzgx, fj_tjtxzgh, fj_tjtcssj from bz_ghtj_jzqys2    b  where  b.cid=v_cid2;
         commit;
           --条件_建筑全要素整体
         delete BZ_GHTJ_JZQYSZT b where b.cid = v_cid1;
         insert into bz_ghtj_jzqyszt
           (id, cid, ydzb_zbsm, ptss_zt, ptss_gg, ptss_sz, wb, jtyq_tcpj, jtyq_crk, jtyq_dk, jtyq_qt, cssjyq_zt, cssjyq_kjxt, cssjyq_jqkz, cssjyq_jzfg, cssjyq_jgzm, cssjyq_wqsz, cssjyq_qt, dxkjyq, jzsjyq_zt,
           jzsjyq_dpbg, jzsjyq_jztr, jzsjyq_jzjj, jzsjyq_fsss, jzsjyq_qt, ghbhyq_jq, ghbhyq_gdjt, ghbhyq_dldx, ghbhyq_hd, ghbhyq_clbz, ghbhyq_lbss, ghbhyq_sthx, ghbhyq_qt, dtstyq_zt, dtstyq_zx, qtghyq, bsyq_zt,
            bsyq_jz, fj, bz, gy_xmgy, gy_zblp, gy_ydmj, gy_jszt, gy_ydmj_zyd, gy_ydmj_kjsyd, gy_ydmj_dzld, gy_ydmj_dzhd, gy_ydmj_dzdl, gy_ydmj_dzgg, gy_ydmj_dzyd, gy_ydmj_hdj, sfhwbtj, jtyq_tcpj_cdshyq, jtyq_tcpj_yzyq,
            dtstyq_zx_hmcsxh,dtstyq_zx_sfwhmcs,dtstyq_zx_hmcsmywrxjl,dtstyq_zx_hmcsnllkzl,FHGH_GYJSYD,FHGH_XZJSYD,NZZ_GYJSYD,BZYFQ,WYYFQ,WYFKC,YFKC,SJYD_JSYD,SJYD_NYD,SJYD_WLYD,SJYD_GYTD,SJYD_JTYD)

         select s_BZ_GHTJ_JZQYSZT.Nextval, v_cid1, ydzb_zbsm, ptss_zt, ptss_gg, ptss_sz, wb, jtyq_tcpj, jtyq_crk, jtyq_dk, jtyq_qt, cssjyq_zt, cssjyq_kjxt, cssjyq_jqkz, cssjyq_jzfg, cssjyq_jgzm, cssjyq_wqsz, cssjyq_qt, dxkjyq, jzsjyq_zt,
          jzsjyq_dpbg, jzsjyq_jztr, jzsjyq_jzjj, jzsjyq_fsss, jzsjyq_qt, ghbhyq_jq, ghbhyq_gdjt, ghbhyq_dldx, ghbhyq_hd, ghbhyq_clbz, ghbhyq_lbss, ghbhyq_sthx, ghbhyq_qt, dtstyq_zt, dtstyq_zx, qtghyq, bsyq_zt,
           bsyq_jz, fj, bz, gy_xmgy, gy_zblp, gy_ydmj, gy_jszt, gy_ydmj_zyd, gy_ydmj_kjsyd, gy_ydmj_dzld, gy_ydmj_dzhd, gy_ydmj_dzdl, gy_ydmj_dzgg, gy_ydmj_dzyd, gy_ydmj_hdj, sfhwbtj, jtyq_tcpj_cdshyq, jtyq_tcpj_yzyq,
           dtstyq_zx_hmcsxh,dtstyq_zx_sfwhmcs,dtstyq_zx_hmcsmywrxjl,dtstyq_zx_hmcsnllkzl,FHGH_GYJSYD,FHGH_XZJSYD,NZZ_GYJSYD,BZYFQ,WYYFQ,WYFKC,YFKC,SJYD_JSYD,SJYD_NYD,SJYD_WLYD,SJYD_GYTD,SJYD_JTYD
            from bz_ghtj_jzqyszt   b  where  b.cid=v_cid2;
       commit;
        --条件_市政全要素
         delete BZ_GHTJ_SZQYS b where b.cid = v_cid1;
         insert into bz_ghtj_szqys
           (id, cid, szgxss_gxzl, szgxss_gxzl_xz, szgxss_gxzl_ghsz, szgxss_gxzl_gs, szgxss_gxzl_ys, szgxss_gxzl_ws, szgxss_gxzl_gd, szgxss_gxzl_rq, szgxss_gxzl_tx, szgxss_gxzl_yxds, szgxss_gxzl_rl,
            szgxss_gxzl_gygd, szgxss_gxzl_qt, szgxss_gxzl_gxgm, szgxss_xjyq_ys, szgxss_xjyq_ysfw, szgxss_xjyq_ysfx, szgxss_xjyq_ws, szgxss_xjyq_wsfw, szgxss_xjyq_wsfx, szgxss_xjyq_gs, szgxss_xjyq_gsfx,
            szgxss_xjyq_zs, szgxss_xjyq_zsfx, szgxss_xjyq_gd, szgxss_xjyq_gdfx, szgxss_xjyq_rq, szgxss_xjyq_rqfx, szgxss_xjyq_tx, gxss_xjyq_txfx, gxss_xjyq_yxds, gxss_xjyq_yxdsfx, gxss_xjyq_yzyq, gxss_ssbz_tryq,
             gxss_ssbz_trjhx, gxss_ssbz_fsyq, gxss_ssbz_jdyq, gxss_ssbz_aqyq, gxss_ssbz_fsssyq, gxss_ssbz_zhgl, gxss_psyq, gxss_psyq_jysg, gxss_psyq_qt, gxss_psyq_ytpw, szbsyq_fasq, szbsyq_fasqgs, szbsyq_fasqzs,
              szbsyq_fasqys, szbsyq_fasqws, szbsyq_fasqgd, szbsyq_fasqrq, szbsyq_fasqtx, szbsyq_fasqyxds, szbsyq_faty, szbsyq_fatyww, szbsyq_fatygdjt, szbsyq_fatysw, szbsyq_fatyqt)
         select s_BZ_GHTJ_SZQYS.Nextval, v_cid1, szgxss_gxzl, szgxss_gxzl_xz, szgxss_gxzl_ghsz, szgxss_gxzl_gs, szgxss_gxzl_ys, szgxss_gxzl_ws, szgxss_gxzl_gd, szgxss_gxzl_rq, szgxss_gxzl_tx, szgxss_gxzl_yxds, szgxss_gxzl_rl,
          szgxss_gxzl_gygd, szgxss_gxzl_qt, szgxss_gxzl_gxgm, szgxss_xjyq_ys, szgxss_xjyq_ysfw, szgxss_xjyq_ysfx, szgxss_xjyq_ws, szgxss_xjyq_wsfw, szgxss_xjyq_wsfx, szgxss_xjyq_gs, szgxss_xjyq_gsfx,
           szgxss_xjyq_zs, szgxss_xjyq_zsfx, szgxss_xjyq_gd, szgxss_xjyq_gdfx, szgxss_xjyq_rq, szgxss_xjyq_rqfx, szgxss_xjyq_tx, gxss_xjyq_txfx, gxss_xjyq_yxds, gxss_xjyq_yxdsfx, gxss_xjyq_yzyq, gxss_ssbz_tryq,
            gxss_ssbz_trjhx, gxss_ssbz_fsyq, gxss_ssbz_jdyq, gxss_ssbz_aqyq, gxss_ssbz_fsssyq, gxss_ssbz_zhgl, gxss_psyq, gxss_psyq_jysg, gxss_psyq_qt, gxss_psyq_ytpw, szbsyq_fasq, szbsyq_fasqgs, szbsyq_fasqzs,
             szbsyq_fasqys, szbsyq_fasqws, szbsyq_fasqgd, szbsyq_fasqrq, szbsyq_fasqtx, szbsyq_fasqyxds, szbsyq_faty, szbsyq_fatyww, szbsyq_fatygdjt, szbsyq_fatysw, szbsyq_fatyqt from bz_ghtj_szqys
              b  where  b.cid=v_cid2;
          commit;
           --条件_市政全要素整体
         delete BZ_GHTJ_SZQYSZT b where b.cid = v_cid1;
         insert into bz_ghtj_szqyszt
           (id, gxjfsss_zt, gxjfsss_xj, gxjfsss_ss, gxjfsss_ps, bsyq_gx, fj, cid)
           select s_bz_ghtj_szqyszt.nextval, gxjfsss_zt, gxjfsss_xj, gxjfsss_ss, gxjfsss_ps, bsyq_gx, fj, v_cid1 from bz_ghtj_szqyszt   b  where  b.cid=v_cid2;
            commit;
            --申报材料
     delete bz_sbcl b where b.cid = v_cid1;
     insert into bz_sbcl
        (id, cid, clmc, clxs, clfs, xh, bb, wh, zzyq, sdfs, dzwj, qj, ygsm, ys, dzwjm, bdw, txr, qsr, cllb, qjjr, thfs, xgfz)
        select s_bz_sbcl.nextval, v_cid1, clmc, clxs, clfs, xh, bb, wh, zzyq, sdfs, dzwj, qj, ygsm, ys, dzwjm, bdw, txr, qsr, cllb, qjjr, thfs, xgfz from bz_sbcl  b  where  b.cid=v_cid2;
         commit;
                --建设用地地块明细
 delete bz_yd_js_dkmx b where b.cid = v_cid1;
   delete bz_yd_js_xzmx b where b.cid = v_cid1;
  for i  in  (
     select s_BZ_YD_JS_DKMX.Nextval as  newid ,id,  cid, dkid, dkmc, dkydxz, ljlmin, ljlmax, ljlsign, jzmdmin, jzmdmax, jzmdsign, ldlmin, ldlmax, ldlsign, jzxgmin, jzxgmax, jzxgsign, jzldx, jzldfh, fh, zhms, dkydmj
   from bz_yd_js_dkmx  b  where  b.cid=v_cid2
    )loop
    insert into bz_yd_js_dkmx
      (id, cid, dkid, dkmc, dkydxz, ljlmin, ljlmax, ljlsign, jzmdmin, jzmdmax, jzmdsign, ldlmin, ldlmax, ldlsign, jzxgmin, jzxgmax, jzxgsign, jzldx, jzldfh, fh, zhms, dkydmj)
    values
      (i.newid, v_cid1, i.dkid, i.dkmc, i.dkydxz, i.ljlmin, i.ljlmax, i.ljlsign, i.jzmdmin, i.jzmdmax, i.jzmdsign, i.ldlmin, i.ldlmax, i.ldlsign, i.jzxgmin, i.jzxgmax, i.jzxgsign, i.jzldx, i.jzldfh, i.fh, i.zhms, i.dkydmj);
      --建设用地性质明细
       insert into bz_yd_js_xzmx
      (id, ydxz, bl, mj, dkbh, cid, ref_bz_yd_js_dkmx_id)
  select s_bz_yd_js_xzmx.nextval, ydxz, bl, mj, dkbh, v_cid1, i.newid from bz_yd_js_xzmx  b where  b.ref_bz_yd_js_dkmx_id =i.id;
      commit;
  end loop;

      end;
      
         
      procedure updateFagcXxxx(v_pid in integer) is
  v_cid integer;
begin
  select cr.cid
    into v_cid
    from bz_caseinstrelation cr
   where cr.pid = v_pid;
  update BZ_FA_DK b
     set b.guid =
         ('bg' || b.guid)
   where b.cid = v_cid;
  update BZ_FA_JZW_D b
     set b.guid             =
         ('bg' || b.guid),
         b.ref_bz_fa_dk_guid =
         ('bg' || b.ref_bz_fa_dk_guid)
   where b.cid = v_cid;
  update BZ_FA_JZW_C b
     set b.guid                =
         ('bg' || b.guid),
         b.ref_bz_fa_dk_guid   =
         ('bg' || b.ref_bz_fa_dk_guid),
         b.ref_bz_fa_jzw_d_guid =
         ('bg' || b.ref_bz_fa_jzw_d_guid)
   where b.cid = v_cid;
  update BZ_FA_JZWGN_C b
    set b.ref_bz_fa_jzw_c_id =
        (select c.id
           from bz_fa_jzw_c c
          where c.guid = (select 'bg' || c.guid
                            from bz_fa_jzw_c c
                           where c.id = b.ref_bz_fa_jzw_c_id))
  where b.cid = v_cid;
 update BZ_FA_JZWGN_D b
    set b.ref_bz_jzw_d_id =
        (select c.id
           from bz_fa_jzw_d c
          where c.guid =
                (select 'bg' || c.guid from bz_fa_jzw_d c where c.id = b.ref_bz_jzw_d_id))
  where b.cid = v_cid;
  update BZ_FAGC_JZYTXXXX b
     set b.guid             =
         ('bg' || b.guid),
         b.d_guid           =
         ('bg' || b.d_guid),
         b.c_guid           =
         ('bg' || b.c_guid),
         b.ref_bz_fa_dk_guid =
         ('bg' || b.ref_bz_fa_dk_guid)
   where b.cid = v_cid;
  commit;
end;

 procedure copyRzfhData(v_pid1 in integer,v_pid2 in integer)  is 
   begin
     insert into bz_rzfh
       (id, pid, fhwc, yjlx, sbbm, sqr, sqrdh, xmmc, xmbh, sxbh, jsdw, lxr, lxrdh, sqsj, jzsj, rwbh, sqsy_1, sqsy1, sqsy_2, sqsy2, sqsy_3, sqsy3, sqsy_4, sqsy4, sqsy_5, sqsy5, fhyq_1, fhyq1, fhyq_2, fhyq2, fhyq_qt, fhyj, jzxmdsjzmj, jsfwnzbjz)
    select s_bz_rzfh.nextval, v_pid1, fhwc, yjlx, sbbm, sqr, sqrdh, xmmc, xmbh, sxbh, jsdw, lxr, lxrdh, sqsj, jzsj, '', sqsy_1, sqsy1, sqsy_2, sqsy2, sqsy_3, sqsy3, sqsy_4, sqsy4, sqsy_5, sqsy5, fhyq_1, fhyq1, fhyq_2, fhyq2, fhyq_qt, fhyj, jzxmdsjzmj, jsfwnzbjz from bz_rzfh  where pid=v_pid2;
  insert into bz_slxx
    (id, sllsh, slr, slsj, qs, zbj, pid, lwlx)
  select s_bz_slxx.nextval, sllsh, slr, slsj, qs, zbj, v_pid1, lwlx from bz_slxx  where pid=v_pid2;
  
   insert into bz_ysqgk_opinion
      (id, pid, sprid, spr, yj, spsj, ssks, sphj, dqbs, instanceid, projectid, folderid, geopeccancybbsoid, qybz)
  select s_bz_ysqgk_opinion.nextval, v_pid1, sprid, spr, yj, spsj, ssks, sphj, dqbs, instanceid, projectid, folderid, geopeccancybbsoid, qybz from bz_ysqgk_opinion  where pid=v_pid2;
  end;
  
  --复制父案件的基本信息数据
  procedure copyDataForGenerateLand(v_pid      in integer,
                                    v_parentpid      in integer,
                                    v_businessname  in varchar2,  
                                    v_businessprocessid  in integer,
                                    v_serialno in varchar2,  
                                    v_volumenumber in integer,
                                    v_roundnumber in integer,
                                    v_createuserid in integer,
                                    v_loginname in varchar2,  
                                    v_casecode in varchar2,
                                    v_projectnumber     in varchar2) is
    parentCid     integer;
    parentBaseId     integer;
    parentDid integer;
    parentDmid integer;
    parentProjectCode varchar2(200);
    parentProjectName varchar2(200);
    
    
    targetDid integer;
    targetDmid integer;
    targetCid integer;
    
    qtyq varchar2(2000);
    fj varchar2(2000);
    bz clob;
  begin
    
     select s_bz_declareinfo.nextval into targetDid from dual;
     select s_bz_declarematterinfo.nextval into targetDmid from dual;
    
     select cr.cid into targetCid from bz_caseinstrelation cr where cr.pid = v_pid;

     select cr.cid into parentCid from bz_caseinstrelation cr where cr.pid = v_parentpid;
     select c.baseid into parentBaseId from bz_projectcase c where c.id = parentCid;
     select c.projectcode into parentProjectCode from bz_projectcase c where c.id = parentCid;
     select c.projectname into parentProjectName from bz_projectcase c where c.id = parentCid;
     select c.ref_declarematterinfo_id into parentDmid from bz_projectcase c where c.id = parentCid;
     select dmi.refdeclareid into parentDid from bz_declarematterinfo dmi where dmi.id = parentDmid; 
    
    -- 生成子项目的 declareinfo，子与父共用 base表
    insert into bz_declareinfo (id, baseid, businesstype, casetype, isconfirm, createtime, createuserid, loginname, gtbh, handletype, parentprojectid, inputgtbh, tempprojecttype)
    select targetDid, parentBaseId, businesstype, casetype, isconfirm, sysdate , v_createuserid, v_loginname, gtbh, handletype, v_parentPid, inputgtbh, tempprojecttype
        from bz_declareinfo d
       where d.id = parentDid;
     
    --生成子项目的 bz_declarematterinfo   
    insert into bz_declarematterinfo (id, businessname, businessid, volumenumber, roundnumber, mainorganname, mainorganid, casecategory, municipaltype, casecode, refdeclareid, lifestate, serialno, municipaltype_max, zwzx_dept_yw_reg_no, maindeptname, maindeptid, businessmodelid)
     select targetDmid, v_businessname, v_businessprocessid, v_volumenumber, v_roundnumber, mainorganname, mainorganid, casecategory, municipaltype, v_casecode, targetDid, lifestate, v_serialno, municipaltype_max, zwzx_dept_yw_reg_no, maindeptname, maindeptid, businessmodelid
        from bz_declarematterinfo dmi
       where dmi.id = parentDmid;  
       
    --更新项目阶段表信息
    update bz_projectcase c
       set c.bizid = v_casecode,
           c.cbdw = parentProjectName || '受让人',
           c.accepttime = sysdate,
           c.casecode = parentProjectCode || v_casecode,
           c.volumenumber = v_volumenumber,
           c.roundnumber  = v_roundnumber,
           c.ref_declarematterinfo_id = targetDmid,
           c.real_volumenumber = v_volumenumber,
           c.real_roundnumber  = v_roundnumber
     where c.id = targetCid;
     
     --更新审批意见信息
     update bz_spyj s set s.yjlx = '许可' where s.cid = targetCid;
     
     --获取其他要求/附件/行政指导和备注的默认值
     for i in (select dv2.name, dv2.value
              from njgh_dap.dcc_dictionarytype dt
              join njgh_dap.dcc_dictionaryvalue dv
                on dt.id = dv.fk_type_id
              join njgh_dap.dcc_dictionaryvalue dv2
                on dv2.fk_dictionaryvalue_id = dv.id
             where dt.name = '默认赋值'
               and dv.name = '建设用地规划许可证') loop
        if i.name = '其他要求' then
           qtyq := replace(i.value,'\n', chr(13)||chr(10) );
        end if;
        if i.name = '条件用地附件' then
           fj := replace(i.value,'\n', chr(13)||chr(10) );
        end if;
        if i.name = '条件用地备注' then
           bz := replace(i.value,'\n', chr(13)||chr(10) );
        end if;
     end loop;
     
     insert into bz_zsxx (id, cid, fzbhsj, fzbh, sfgs, fzbhqxsj, qtsm, fj, bz) 
     values (s_bz_zsxx.nextval, targetCid, sysdate, v_projectnumber, '在使用', add_months(sysdate,12) - 1, qtyq, fj, bz);
     
      --生成子项目的建设用地地块明细，复制父案件的数据
     insert into bz_yd_js_dkmx (id, cid, dkid, dkmc, dkydxz, ljlmin, ljlmax, ljlsign, jzmdmin, jzmdmax, jzmdsign, ldlmin, ldlmax, ldlsign, jzxgmin, jzxgmax, jzxgsign, jzldx, jzldfh, fh, zhms, dkydmj, mu_sd, sfdx, dkidzh, qy)
     select s_bz_yd_js_dkmx.nextval, targetCid, dkid, dkmc, dkydxz, ljlmin, ljlmax, ljlsign, jzmdmin, jzmdmax, jzmdsign, ldlmin, ldlmax, ldlsign, jzxgmin, jzxgmax, jzxgsign, jzldx, jzldfh, fh, zhms, dkydmj, mu_sd, sfdx, dkidzh, qy
        from bz_yd_js_dkmx d
       where d.cid = parentCid;
       
      --生成子项目的选址用地核心数据，复制父案件的数据
      insert into bz_xzyd (id, cid, sfgs, jsdd, xzsy, xzwz, jsydmjhj, dzydmjhj, dkzmj, qtsm, xzsy_qt, zhmshj, sfcjax, sfhwbtj, sfcbyd, xzlx, jsyj, ydysxzyjbh, fj, xzzdbz, ycyysm, rjl, jzmd, ydysyxzyjspzwh, bgsly, bgslyqtsm, transfer, cxghfw, tdsyqxz, tdsqsynx, zdmj, fgbzj)
      select s_bz_xzyd.nextval, targetCid, sfgs, jsdd, xzsy, xzwz, jsydmjhj, dzydmjhj, dkzmj, qtsm, xzsy_qt, zhmshj, sfcjax, sfhwbtj, sfcbyd, xzlx, jsyj, ydysxzyjbh, fj, xzzdbz, ycyysm, rjl, jzmd, ydysyxzyjspzwh, bgsly, bgslyqtsm, transfer, cxghfw, tdsyqxz, tdsqsynx, zdmj, fgbzj
        from bz_xzyd x
       where x.cid = parentCid;
       
    commit;
  
  end;
  
  --更新系统项目表信息
  procedure updateProjectInfoForParent(v_parentpid in integer,
                                       v_pid       in integer) is
    targetCid integer;
    parentCid integer;
  begin
    select cr.cid
      into targetCid
      from bz_caseinstrelation cr
     where cr.pid = v_pid;
  
    select cr.cid
      into parentCid
      from bz_caseinstrelation cr
     where cr.pid = v_parentpid;
     
    --更新系统表信息
    for i in (select p.mainorganid,
                     p.mainorganname,
                     p.mainuserid,
                     p.mainusername
                from pcc_project p
               where p.id = v_parentpid
                 and rownum = 1) loop
      update pcc_project p
         set p.createtype     = 12,
             p.mainorganid    = i.mainorganid,
             p.mainorganname  = i.mainorganname,
             p.mainuserid     = i.mainuserid,
             p.mainusername   = i.mainusername,
             p.registerstate  = 1,
             p.registerdate   = sysdate,
             p.lastmodifytime = sysdate
       where id = v_pid;
    end loop;
  
    --更新项目阶段表信息
    for i in (select c.baseid,
                     c.projectcode,
                     c.projectname,
                     c.xmdz,
                     c.businesstype,
                     c.casetype,
                     c.mainorganname,
                     c.mainorganid,
                     c.casecategory,
                     c.sbsj,
                     c.gdfs,
                     c.nxwz,
                     c.hwbtj,
                     c.dz_q,
                     c.dz_jd,
                     c.dz_xxdz,
                     c.sfzsdt,
                     c.dzsfgd,
                     c.jbr1,
                     c.jbr2,
                     c.jbrid1,
                     c.jbrid2,
                     c.sfsm,
                     c.xmdm,
                     c.gdlx
                from bz_projectcase c
               where c.id = parentCid
                 and rownum = 1) loop
      update bz_projectcase c
         set c.baseid        = i.baseid,
             c.projectcode   = i.projectcode,
             c.projectname   = i.projectname,
             c.xmdz          = i.xmdz,
             c.businesstype  = i.businesstype,
             c.casetype      = i.casetype,
             c.mainorganname = i.mainorganname,
             c.mainorganid   = i.mainorganid,
             c.casecategory  = i.casecategory,
             c.sbsj          = i.sbsj,
             c.gdfs          = i.gdfs,
             c.nxwz          = i.nxwz,
             c.hwbtj         = i.hwbtj,
             c.dz_q          = i.dz_q,
             c.dz_jd         = i.dz_jd,
             c.dz_xxdz       = i.dz_xxdz,
             c.sfzsdt        = i.sfzsdt,
             c.dzsfgd        = i.dzsfgd,
             c.jbr1          = i.jbr1,
             c.jbr2          = i.jbr2,
             c.jbrid1        = i.jbrid1,
             c.jbrid2        = i.jbrid2,
             c.sfsm          = i.sfsm,
             c.xmdm          = i.xmdm,
             c.gdlx          = i.gdlx
       where c.id = targetCid;
    end loop;
  
    commit;
  
  end;
  
end DP_copydata;
/

