create view VS_PROJECTACTIVITYNAME as
select k.activity_name, p.id,k.status
  from bpmdbadev.lsw_task k
  left join pcc_project p
    on p.processinstanceid = k.bpd_instance_id
/

