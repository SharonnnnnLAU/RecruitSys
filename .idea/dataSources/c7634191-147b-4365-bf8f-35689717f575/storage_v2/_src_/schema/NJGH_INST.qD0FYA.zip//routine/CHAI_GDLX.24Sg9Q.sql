create function chai_gdlx(v_gdlx in varchar2) return varchar2 is
  Result varchar2(40);
begin
    if  INSTR(v_gdlx, ',', 1, 1)=0 then

       return v_gdlx;
    else
       return SUBSTR(v_gdlx, 0, (INSTR(v_gdlx, ',', 1, 1) - 1));
    end  if;
  return(Result);
end chai_gdlx;
/

