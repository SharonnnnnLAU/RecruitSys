create package body PHGL_JZBYX is
--发证啊
procedure fzxk(rzttable  out r_cursor,
                startdate in date,
                enddate   in date,
                v_q       in varchar,
                v_gdlx    in varchar,
                v_bm in varchar,
                v_ry in varchar,
                v_fl in varchar,
                v_xj       in varchar,
                v_yqbm     in varchar,
                noshowdata in integer) as
begin
    if noshowdata = 1 then
      open rzttable for
        select null as 分类栏,null as 分类栏1,null as 件次, null as 栋数
         from dual;
      return;
end if;

if  v_fl='行政区' then--分类栏选择行政区
   if v_ry is null then
     open rzttable for
       select    chai_q(c.dz_q)AS 分类栏,
           '' as 分类栏1,
         count(*) as 件次,sum(A.ds)  as 栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     left join (
     select d.cid,count(*) as ds from bz_fa_jzw_d  d
     group by d.cid) A on A.cid=c.id
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
       and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
                           --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null and v_xj is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))

group by chai_q(c.dz_q)
order by chai_q(c.dz_q);


   end if;

   if v_ry is not null then
      open rzttable for
       select    chai_q(c.dz_q)AS 分类栏,
           '' as 分类栏1,
         count(*) as 件次,sum(A.ds)  as 栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     left join (
     select d.cid,count(*) as ds from bz_fa_jzw_d  d
     group by d.cid) A on A.cid=c.id
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
       and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --人员参数
          and c.jbr1 in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_ry as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_ry as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
group by chai_q(c.dz_q)
order by chai_q(c.dz_q);
end if;
return;
end if;

if  v_fl='部门' and v_xj = 1 then --分类栏选择部门
      --包括下级部门

   if v_ry is null then
      open rzttable for
       select    case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end AS 分类栏,
       org.shortname as 分类栏1,
         count(*) as 件次,sum(A.ds)  as 栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     left join (
     select d.cid,count(*) as ds from bz_fa_jzw_d  d
     group by d.cid) A on A.cid=c.id
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
        --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))
      group by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end,org.shortname
      order by max(case when forg.id = 1007309 then org.sortno else forg.sortno end );


   return;
   end if;

   if v_ry is not null then
      open rzttable for
 select    case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end AS 分类栏,
           org.shortname as 分类栏1,
         count(*) as 件次,sum(A.ds)  as 栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     left join (
     select d.cid,count(*) as ds from bz_fa_jzw_d  d
     group by d.cid) A on A.cid=c.id
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --人员参数
             and c.jbr1 in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_ry as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_ry as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
        --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))
      group by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end,org.shortname
      order by max(case when forg.id = 1007309 then org.sortno else forg.sortno end );


   return;
   end if;

return;
end if;

if  v_fl='部门'  then --分类栏选择部门--不包括下级部门

   if v_ry is null then
      open rzttable for
       select    case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end AS 分类栏,
           '' as 分类栏1,
         count(*) as 件次,sum(A.ds)  as 栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     left join (
     select d.cid,count(*) as ds from bz_fa_jzw_d  d
     group by d.cid) A on A.cid=c.id
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
        --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))
      group by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end
      order by max(case when forg.id = 1007309 then org.sortno else forg.sortno end );


   return;
   end if;

   if v_ry is not null then
      open rzttable for
    select    case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end AS 分类栏,
           ''as 分类栏1,
         count(*) as 件次,sum(A.ds)  as 栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     left join (
     select d.cid,count(*) as ds from bz_fa_jzw_d  d
     group by d.cid) A on A.cid=c.id
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --人员参数
            and c.jbr1 in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_ry as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_ry as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
        --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))
      group by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end
      order by max(case when forg.id = 1007309 then org.sortno else forg.sortno end );


   return;
   end if;

return;
end if;  --结束
end fzxk;
procedure jzbyx(rzttable  out r_cursor,
                startdate in date,
                enddate   in date,
                v_q       in varchar,
                v_gdlx    in varchar,
                v_bm in varchar,
                v_ry in varchar,
                v_fl in varchar,
                v_xj       in varchar,
                v_yqbm     in varchar,
                noshowdata in integer) as
begin
    if noshowdata = 1 then
      open rzttable for
        select null as 分类栏,null as 分类栏1,
        NULL AS 正负零件数,
         NULL AS 正负零栋数,
          NULL  AS 合格正负零件数,
           NULL  AS 合格正负零栋数,

           NULL AS 验灰线件数,
            NULL  AS 验灰线栋数,
            NULL  AS 合格验灰线件数,
           NULL  AS 合格验灰线栋数
         from dual;
      return;
end if;

if  v_fl='行政区' then--分类栏选择行政区
   if v_ry is null then
     open rzttable for
      select   chai_q(c.dz_q)AS 分类栏,
          '' as 分类栏1,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.验线件数 END) AS 正负零件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.栋数 END) AS 正负零栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.验线件数 END) AS 合格正负零件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.栋数 END) AS 合格正负零栋数,

           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.验线件数 END) AS 验灰线件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.栋数 END) AS 验灰线栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.验线件数 END) AS 合格验灰线件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.栋数 END) AS 合格验灰线栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     left join bz_zsxx zs on zs.cid=spb.cid
     left join bz_spyj sp on sp.cid=spb.cid
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where zs.fzbh is not null  and zs.sfgs='在使用'
     and sp.yjxz='同意' AND P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     and spb.scjg in ('符合','合格')
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) B ON B.CID=C.ID

      LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where  P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) D ON D.CID=C.ID
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
       and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
                           --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null and v_xj is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))

group by chai_q(c.dz_q);


   end if;

   if v_ry is not null then
      open rzttable for
       select    chai_q(c.dz_q)AS 分类栏,
           '' as 分类栏1,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.验线件数 END) AS 正负零件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.栋数 END) AS 正负零栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.验线件数 END) AS 合格正负零件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.栋数 END) AS 合格正负零栋数,

           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.验线件数 END) AS 验灰线件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.栋数 END) AS 验灰线栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.验线件数 END) AS 合格验灰线件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.栋数 END) AS 合格验灰线栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     left join bz_zsxx zs on zs.cid=spb.cid
     left join bz_spyj sp on sp.cid=spb.cid
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where zs.fzbh is not null  and zs.sfgs='在使用'
     and sp.yjxz='同意' AND P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     and spb.scjg in ('符合','合格')
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) B ON B.CID=C.ID

      LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where  P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) D ON D.CID=C.ID
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
       and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --人员参数
          and c.jbr1 in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_ry as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_ry as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
group by chai_q(c.dz_q);
end if;
return;
end if;

if  v_fl='部门' and v_xj = 1 then --分类栏选择部门
      --包括下级部门

   if v_ry is null then
      open rzttable for
       select    case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end AS 分类栏,
       org.shortname as 分类栏1,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.验线件数 END) AS 正负零件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.栋数 END) AS 正负零栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.验线件数 END) AS 合格正负零件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.栋数 END) AS 合格正负零栋数,

           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.验线件数 END) AS 验灰线件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.栋数 END) AS 验灰线栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.验线件数 END) AS 合格验灰线件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.栋数 END) AS 合格验灰线栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     left join bz_zsxx zs on zs.cid=spb.cid
     left join bz_spyj sp on sp.cid=spb.cid
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where zs.fzbh is not null  and zs.sfgs='在使用'
     and sp.yjxz='同意' AND P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     and spb.scjg in ('符合','合格')
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) B ON B.CID=C.ID

      LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where  P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) D ON D.CID=C.ID
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
        --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))
      group by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end,org.shortname
      order by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end;


   return;
   end if;

   if v_ry is not null then
      open rzttable for
 select    case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end AS 分类栏,
           org.shortname as 分类栏1,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.验线件数 END) AS 正负零件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.栋数 END) AS 正负零栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.验线件数 END) AS 合格正负零件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.栋数 END) AS 合格正负零栋数,

           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.验线件数 END) AS 验灰线件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.栋数 END) AS 验灰线栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.验线件数 END) AS 合格验灰线件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.栋数 END) AS 合格验灰线栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     left join bz_zsxx zs on zs.cid=spb.cid
     left join bz_spyj sp on sp.cid=spb.cid
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where zs.fzbh is not null  and zs.sfgs='在使用'
     and sp.yjxz='同意' AND P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     and spb.scjg in ('符合','合格')
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) B ON B.CID=C.ID

      LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where  P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) D ON D.CID=C.ID
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --人员参数
             and c.jbr1 in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_ry as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_ry as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
        --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))
      group by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end,org.shortname
      order by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end;


   return;
   end if;

return;
end if;

if  v_fl='部门'  then --分类栏选择部门--不包括下级部门

   if v_ry is null then
      open rzttable for
       select    case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end AS 分类栏,
           '' as 分类栏1,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.验线件数 END) AS 正负零件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.栋数 END) AS 正负零栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.验线件数 END) AS 合格正负零件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.栋数 END) AS 合格正负零栋数,

           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.验线件数 END) AS 验灰线件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.栋数 END) AS 验灰线栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.验线件数 END) AS 合格验灰线件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.栋数 END) AS 合格验灰线栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     left join bz_zsxx zs on zs.cid=spb.cid
     left join bz_spyj sp on sp.cid=spb.cid
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where zs.fzbh is not null  and zs.sfgs='在使用'
     and sp.yjxz='同意' AND P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     and spb.scjg in ('符合','合格')
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) B ON B.CID=C.ID

      LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where  P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) D ON D.CID=C.ID
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
        --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))
      group by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end
      order by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end;


   return;
   end if;

   if v_ry is not null then
      open rzttable for
    select    case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end AS 分类栏,
           ''as 分类栏1,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.验线件数 END) AS 正负零件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验±0' THEN D.栋数 END) AS 正负零栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.验线件数 END) AS 合格正负零件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验±0' THEN B.栋数 END) AS 合格正负零栋数,

           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.验线件数 END) AS 验灰线件数,
           SUM(CASE WHEN D.BIZSMALLNAME='验灰线' THEN D.栋数 END) AS 验灰线栋数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.验线件数 END) AS 合格验灰线件数,
           SUM(CASE WHEN B.BIZSMALLNAME='验灰线' THEN B.栋数 END) AS 合格验灰线栋数
      from pcc_project p
      left join bz_caseinstrelation r
        on r.pid = p.id
      left join bz_projectcase c
        on c.id = r.cid
      left join bz_spyj yj
        on yj.cid = c.id
      left join temp_xzj j
        on 1 = 1
      left join njgh_sec.dcc_org org
        on org.id = p.mainorganid
      left join njgh_sec.dcc_org forg
        on forg.id = org.parentid
      left join pdt_projectbase ba
        on ba.id = c.baseid
     left join bz_zsxx zs on zs.cid=c.id
     LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     left join bz_zsxx zs on zs.cid=spb.cid
     left join bz_spyj sp on sp.cid=spb.cid
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where zs.fzbh is not null  and zs.sfgs='在使用'
     and sp.yjxz='同意' AND P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     and spb.scjg in ('符合','合格')
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) B ON B.CID=C.ID

      LEFT JOIN (SELECT  A.BIZSMALLNAME,A.CID,COUNT(*) AS 验线件数,sum(A.栋数) as 栋数 from
     (
     select C.BIZSMALLNAME,D.CID,SPB.CID as cid2,count(*) as 栋数  from  bz_fa_jzw_d d
     left join bz_jzyxspb spb on spb.xkxzid=d.id
     LEFT JOIN BZ_PROJECTCASE C ON C.ID=SPB.CID
     LEFT JOIN BZ_CASEINSTRELATION R ON R.CID=C.ID
     LEFT JOIN PCC_PROJECT P ON P.ID=R.PID
     where  P.PROCESSSTATE='结案'
     and p.fk_business_id=68
     and p.lifestate != '删除'
     GROUP BY C.BIZSMALLNAME,D.CID,SPB.CID
     )A GROUP BY A.BIZSMALLNAME,A.CID) D ON D.CID=C.ID
     where  p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
            --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
            --部门参数
            and ( (v_bm is null) or
                  (v_bm is not null and org.shortname in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )) or
                     (v_bm is not null and forg.shortname  in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_bm as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_bm as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))


            )
            --人员参数
            and c.jbr1 in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_ry as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_ry as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )
            --供地类型参数
         and ((v_gdlx is null) or
              (v_gdlx is not null and instr(ba.gdlx, ',')=0 and ba.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))or
              (v_gdlx is not null and instr(ba.gdlx, ',')>0
               and (ba.id in
             (select distinct a.id
                   from (SELECT a.id,
                                substr(a.gdlx,
                                       instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                       instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                       (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                           FROM (SELECT e.id,
                                        ',' || e.gdlx || ',' AS gdlx,
                                        length(e.gdlx) -
                                        nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                   FROM pdt_projectbase e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.gdlx || ',') -
                                                    nvl(length(REPLACE(e.gdlx,
                                                                       ',')),
                                                        0)) max_len
                                           FROM pdt_projectbase e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt) a
                  where a.gdlx in
                        (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_gdlx as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_gdlx as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         ))))
                         )
        --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null) or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1))
      group by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end
      order by case when forg.id = '1007309' then to_char(org.shortname) else  to_char(forg.shortname) end;


   return;
   end if;

return;
end if;  --结束
end jzbyx;

--统计清单

procedure tjqd(rzttable  out r_cursor,
                startdate in date,
                enddate   in date,
                v_q       in varchar,
                v_gdlx    in varchar,
                v_bm in varchar,
                v_ry in varchar,
                v_fl in varchar,
                --v_xj       in varchar,
                v_yqbm     in varchar,
                noshowdata in integer) as
   begin
   if noshowdata = 1 then
     open rzttable for
       select  '' as 序号,
'' as 项目编号,
--''as 建设单位,
'' as 建设单位名称,
'' as 项目名称,
''as 项目地址,
 '' as 事项名称,
'' as 卷次轮次,
''as bizsmallname,
'' AS  证书编号,
'' as endtime,
'' as processstate,
'' as 联系人,
'' as 联系电话,
'' as 超期天数,'' as 轮次,
''as 经办人,''as 行政区 ,''as 部门,''as 人员 from dual;
     return;
   end if;

   --分类栏选择人员
if  v_fl='人员' then
 open rzttable for
 select

       row_number() over(ORDER BY p.endtime) as 序号,
       c.projectcode  as 项目编号,
       --ba.jsdwmc as 建设单位,
       dw.dwmc as 建设单位名称,
       c.projectname as 项目名称,
       ba.jsdz as 项目地址,
       p.businessname as 事项名称,
       c.bizid as 卷次轮次,
       c.bizsmallname,
        CASE to_char(YJ.YJXZ)
         WHEN '同意' then
          ZS.FZBH
         WHEN '否定' then
          TZS.BYXKJDSH
       END AS  证书编号,
       p.endtime,
       p.processstate,
       bjr.bjrmc as 联系人,
       bjr.bjryddh as 联系电话,
       p.remainingdays as 超期天数,c.roundnumber as 轮次,
       c.jbr1 as 经办人,c.dz_q as 行政区 ,p.mainorganname as 部门,op.username as 人员
  from pcc_project p
  left join (
  select op.projectid,op.username from pcc_projectoperate op
where op.activityname in ('初审','复审','审定','初审会办','复审会办','审定会办','审核','复核','审核会办','复核会办',
'建筑初审','建筑复审','建筑审定','建筑初审会办','建筑复审会办','建筑审定会办',
'市政初审','市政复审','市政审定','市政初审会办','市政复审会办','市政审定会办')
group by op.projectid,op.username
  ) op on op.projectid=p.id
 left join bz_caseinstrelation r
    on r.pid = p.id
  left join bz_projectcase c
    on c.id = r.cid
  left join pdt_projectbase ba
    on ba.id = c.baseid
  LEFT JOIN BZ_SPYJ YJ
    ON YJ.CID = C.ID
 LEFT JOIN BZ_ZSXX ZS
    ON ZS.CID = C.ID
  LEFT JOIN BZ_TZSXX TZS
    ON TZS.CID = C.ID
  left join njgh_sec.dcc_org org
    on org.id = p.mainorganid
  left join njgh_sec.dcc_org forg
    on forg.id = org.parentid
 left join (
         select wb.baseid,wb.dwmc,nvl(tyshxydm,jgdm) as dwdm
         from (
             select pb.id,min(w.id) wid
             from bz_jsdw_xm w
             inner join PDT_PROJECTBASE pb on w.baseid = pb.id
             group by pb.id
           ) wa
         inner join bz_jsdw_xm wb on wa.wid = wb.id
      ) dw on dw.baseid = ba.id
    left join (
         select bjrb.baseid,bjrb.bjrmc,bjrb.bjryddh
         from (
             select pb.id,min(r.id) rid
             from bz_bjr_xm r
             inner join PDT_PROJECTBASE pb on r.baseid = pb.id
             group by pb.id
           ) bjra
         inner join  bz_bjr_xm bjrb on bjra.rid = bjrb.id
      ) bjr on bjr.baseid = ba.id
where    p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
    --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
 --部门参数
       and ((v_bm is null) or
           (v_bm is not null and
           org.shortname in
           (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_bm as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_bm as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt

              )) or
           (v_bm is not null and
           forg.shortname in
           (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_bm as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_bm as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt

              ))

           )
   --人员参数
and  op.username in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_ry as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_ry as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )

          --供地类型参数
       and ((v_gdlx is null) or
           (v_gdlx is not null and instr(ba.gdlx, ',') = 0 and
           ba.gdlx in
           (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_gdlx as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_gdlx as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt

              )) or
           (v_gdlx is not null and instr(ba.gdlx, ',') > 0 and
           (ba.id in
           (select distinct a.id
                 from (SELECT a.id,
                              substr(a.gdlx,
                                     instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                     instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                     (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                         FROM (SELECT e.id,
                                      ',' || e.gdlx || ',' AS gdlx,
                                      length(e.gdlx) -
                                      nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                 FROM pdt_projectbase e) a,
                              (SELECT rownum AS lvl
                                 FROM (SELECT MAX(length(e.gdlx || ',') -
                                                  nvl(length(REPLACE(e.gdlx,
                                                                     ',')),
                                                      0)) max_len
                                         FROM pdt_projectbase e)
                               CONNECT BY LEVEL <= max_len) levels
                        WHERE levels.lvl <= a.cnt) a
                where a.gdlx in
                      (SELECT substr(a.xzq,
                                     instr(a.xzq, ',', 1, levels.lvl) + 1,
                                     instr(a.xzq, ',', 1, levels.lvl + 1) -
                                     (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                         FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                      length(e.xzq) -
                                      nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                 FROM (select v_gdlx as xzq from dual) e) a,
                              (SELECT rownum AS lvl
                                 FROM (SELECT MAX(length(e.xzq || ',') -
                                                  nvl(length(REPLACE(e.xzq, ',')),
                                                      0)) max_len
                                         FROM (select v_gdlx as xzq from dual) e)
                               CONNECT BY LEVEL <= max_len) levels
                        WHERE levels.lvl <= a.cnt

                       )))))
                --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null)
           or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1)) ;
 else
  open rzttable for
  select row_number() over(ORDER BY p.endtime) as 序号,
       c.projectcode  as 项目编号,
       --ba.jsdwmc as 建设单位,
       dw.dwmc as 建设单位名称,
       c.projectname as 项目名称,
       ba.jsdz as 项目地址,
       p.businessname as 事项名称,
       c.bizid as 卷次轮次,
       c.bizsmallname,
        CASE to_char(YJ.YJXZ)
         WHEN '同意' then
          ZS.FZBH
         WHEN '否定' then
          TZS.BYXKJDSH
       END AS  证书编号,
       p.endtime,
       p.processstate,
       bjr.bjrmc as 联系人,
       bjr.bjryddh as 联系电话,
       p.remainingdays as 超期天数,c.roundnumber as 轮次,
       c.jbr1 as 经办人,c.dz_q as 行政区 ,p.mainorganname as 部门,
       '' as 人员
  from pcc_project p
  left join bz_caseinstrelation r
    on r.pid = p.id
  left join bz_projectcase c
    on c.id = r.cid
  left join pdt_projectbase ba
    on ba.id = c.baseid
  LEFT JOIN BZ_SPYJ YJ
    ON YJ.CID = C.ID
 LEFT JOIN BZ_ZSXX ZS
    ON ZS.CID = C.ID
  LEFT JOIN BZ_TZSXX TZS
    ON TZS.CID = C.ID
  left join njgh_sec.dcc_org org
    on org.id = p.mainorganid
  left join njgh_sec.dcc_org forg
    on forg.id = org.parentid
 left join (
         select wb.baseid,wb.dwmc,nvl(tyshxydm,jgdm) as dwdm
         from (
             select pb.id,min(w.id) wid
             from bz_jsdw_xm w
             inner join PDT_PROJECTBASE pb on w.baseid = pb.id
             group by pb.id
           ) wa
         inner join bz_jsdw_xm wb on wa.wid = wb.id
      ) dw on dw.baseid = ba.id
    left join (
         select bjrb.baseid,bjrb.bjrmc,bjrb.bjryddh
         from (
             select pb.id,min(r.id) rid
             from bz_bjr_xm r
             inner join PDT_PROJECTBASE pb on r.baseid = pb.id
             group by pb.id
           ) bjra
         inner join  bz_bjr_xm bjrb on bjra.rid = bjrb.id
      ) bjr on bjr.baseid = ba.id
where   p.fk_business_id=66
       and p.processstate = '结案'
        and p.lifestate != '删除'--排除掉删除的案子
        and p.registerstate=1 --排除未立案的
        and p.createtype=12--排除变更的案子
       and zs.fzbhsj >= startdate
       and zs.fzbhsj <= enddate
    --行政区参数
         and ( (v_q is null) or
              (v_q is not null and chai_q(c.dz_q) in
             (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_q as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_q as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt))

               )
 --部门参数
       and ((v_bm is null) or
           (v_bm is not null and
           org.shortname in
           (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_bm as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_bm as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt

              )) or
           (v_bm is not null and
           forg.shortname in
           (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_bm as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_bm as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt

              ))

           )

          --人员参数
       and ( (v_ry is null) or
             (v_ry is not  null and c.jbr1 in (SELECT substr(a.xzq,
                                       instr(a.xzq, ',', 1, levels.lvl) + 1,
                                       instr(a.xzq, ',', 1, levels.lvl + 1) -
                                       (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                           FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                        length(e.xzq) -
                                        nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                   FROM (select v_ry as xzq from dual) e) a,
                                (SELECT rownum AS lvl
                                   FROM (SELECT MAX(length(e.xzq || ',') -
                                                    nvl(length(REPLACE(e.xzq,
                                                                       ',')),
                                                        0)) max_len
                                           FROM (select v_ry as xzq from dual) e)
                                 CONNECT BY LEVEL <= max_len) levels
                          WHERE levels.lvl <= a.cnt

                         )))

          --供地类型参数
       and ((v_gdlx is null) or
           (v_gdlx is not null and instr(ba.gdlx, ',') = 0 and
           ba.gdlx in
           (SELECT substr(a.xzq,
                            instr(a.xzq, ',', 1, levels.lvl) + 1,
                            instr(a.xzq, ',', 1, levels.lvl + 1) -
                            (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                FROM (SELECT ',' || e.xzq || ',' AS xzq,
                             length(e.xzq) -
                             nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                        FROM (select v_gdlx as xzq from dual) e) a,
                     (SELECT rownum AS lvl
                        FROM (SELECT MAX(length(e.xzq || ',') -
                                         nvl(length(REPLACE(e.xzq, ',')), 0)) max_len
                                FROM (select v_gdlx as xzq from dual) e)
                      CONNECT BY LEVEL <= max_len) levels
               WHERE levels.lvl <= a.cnt

              )) or
           (v_gdlx is not null and instr(ba.gdlx, ',') > 0 and
           (ba.id in
           (select distinct a.id
                 from (SELECT a.id,
                              substr(a.gdlx,
                                     instr(a.gdlx, ',', 1, levels.lvl) + 1,
                                     instr(a.gdlx, ',', 1, levels.lvl + 1) -
                                     (instr(a.gdlx, ',', 1, levels.lvl) + 1)) as gdlx
                         FROM (SELECT e.id,
                                      ',' || e.gdlx || ',' AS gdlx,
                                      length(e.gdlx) -
                                      nvl(length(REPLACE(e.gdlx, ',')), 0) + 1 AS cnt
                                 FROM pdt_projectbase e) a,
                              (SELECT rownum AS lvl
                                 FROM (SELECT MAX(length(e.gdlx || ',') -
                                                  nvl(length(REPLACE(e.gdlx,
                                                                     ',')),
                                                      0)) max_len
                                         FROM pdt_projectbase e)
                               CONNECT BY LEVEL <= max_len) levels
                        WHERE levels.lvl <= a.cnt) a
                where a.gdlx in
                      (SELECT substr(a.xzq,
                                     instr(a.xzq, ',', 1, levels.lvl) + 1,
                                     instr(a.xzq, ',', 1, levels.lvl + 1) -
                                     (instr(a.xzq, ',', 1, levels.lvl) + 1)) as xzq
                         FROM (SELECT ',' || e.xzq || ',' AS xzq,
                                      length(e.xzq) -
                                      nvl(length(REPLACE(e.xzq, ',')), 0) + 1 AS cnt
                                 FROM (select v_gdlx as xzq from dual) e) a,
                              (SELECT rownum AS lvl
                                 FROM (SELECT MAX(length(e.xzq || ',') -
                                                  nvl(length(REPLACE(e.xzq, ',')),
                                                      0)) max_len
                                         FROM (select v_gdlx as xzq from dual) e)
                               CONNECT BY LEVEL <= max_len) levels
                        WHERE levels.lvl <= a.cnt

                       )))))
                --是否包含以前部门
      and ((v_yqbm is null and org.neworgguid is null)
           or(v_yqbm = 0 and org.neworgguid is null) or (v_yqbm = 1)) ;

return;
end if;--结束，分类栏选择人员
end tjqd;
end PHGL_JZBYX;
/

