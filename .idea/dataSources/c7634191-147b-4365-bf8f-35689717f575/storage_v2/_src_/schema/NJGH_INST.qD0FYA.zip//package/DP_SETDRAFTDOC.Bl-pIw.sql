create package DP_setDraftDoc is

  -- Author  : honglei
  -- Created : 2020/08/13 10:55:04

  --用地业务：局长审批环节设置拟稿纸bz_doc
  procedure setYdDoc(v_pid in integer);

  --供地业务：局长审批环节设置拟稿纸bz_doc
  procedure setGdProjectDoc(v_pid in integer);

end DP_setDraftDoc;
/

