create PROCEDURE COPYDATABASE(OLDBASEID IN INTEGER,
                                         NEWBASEID IN INTEGER) IS
BEGIN
  --基本信息
     for i in (
   SELECT NEWBASEID,
           PROJECTNAME, 
           PROJECTCODE,
           JSDWMC, 
           XMLX, 
           DZ_Q, 
           DZ_JD, 
           DZ_XXDZ, 
           XMDM,
           CSTXDW, 
           ZDXM, 
           GDLX, 
           SFBL,
           SFJYJSXM,
           SFSM, 
           SFSW,
           JTSZXMLX 
      FROM PDT_PROJECTBASE
     WHERE ID = OLDBASEID) loop
   update pdt_projectbase pc 
   set 
             pc.id                = i.newbaseid, --项目表id
             pc.projectname       = i.projectname, --项目名称
             pc.projectcode       = i.projectcode, --项目编号  项目编号在启动流程的时候生成的 故 base没数据
             pc.JSDWMC              = i.jsdwmc, --承办单位
             pc.dz_q              = i.dz_q, --地址_区
             pc.dz_jd             = i.dz_jd, --地址_街道
             pc.dz_xxdz           = i.dz_xxdz, --地址_详细地址
             pc.XMDM              = i.XMDM, --是否增设电梯
             pc.CSTXDW            = i.CSTXDW, --是否农民建房
             pc.zdxm              = i.zdxm,
             pc.gdlx              = i.gdlx,
             pc.sfbl              = i.sfbl,
             pc.sfjyjsxm          = i.sfjyjsxm,
             pc.sfsm              = i.sfsm, --是否涉密
             pc.sfsw              = i.sfsw,
             pc.JTSZXMLX          = i.JTSZXMLX;
       end loop;
  --????baseId  ????????
  INSERT INTO BZ_JSDW_XM JX
    (JX.ID,
     JX.DWMC,
     JX.DWXZ,
     JX.DZ_XXDZ,
     JX.TYSHXYDM,
     JX.JGDM,
     JX.FRDB,
     JX.DWXMFZR,
     JX.FRZJLX,
     JX.FRRSFZ,
     JX.XZXDRLB,
     JX.BASEID)
    SELECT S_BZ_JSDW_XM.NEXTVAL,
           JSDW.DWMC,
           JSDW.DWXZ,
           JSDW.DZ_XXDZ,
           JSDW.TYSHXYDM,
           JSDW.JGDM,
           JSDW.FRDB,
           JSDW.DWXMFZR,
           JSDW.FRZJLX,
           JSDW.FRRSFZ,
           JSDW.XZXDRLB,
           NEWBASEID
      FROM BZ_JSDW_XM JSDW
     WHERE JSDW.BASEID = OLDBASEID;
     
     --??????
       INSERT INTO bz_bjr_xm bjr
             (bjr.ID,
             bjr.bjrmc,
             bjr.bjryddh,
             bjr.zjlx,
             bjr.zjh,
             bjr.BASEID)
    SELECT s_bz_bjr_xm.NEXTVAL,
             bj.bjrmc,
             bj.bjryddh,
             bj.zjlx,
             bj.zjh,
             NEWBASEID
      FROM bz_bjr_xm bj
     WHERE bj.BASEID = OLDBASEID;
  COMMIT;
END;
/

