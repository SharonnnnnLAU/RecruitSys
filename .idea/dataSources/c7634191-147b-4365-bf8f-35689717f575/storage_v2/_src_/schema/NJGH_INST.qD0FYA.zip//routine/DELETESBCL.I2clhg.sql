create procedure deleteSbcl(cid  in integer) is
countTj integer;
begin
  select count(*) into countTj from bz_sbcl b where b.cid = cid;
  if countTj > 0 then
    delete bz_sbcl b where b.cid = cid;
    commit;
  end if;
end deleteSbcl;

/

