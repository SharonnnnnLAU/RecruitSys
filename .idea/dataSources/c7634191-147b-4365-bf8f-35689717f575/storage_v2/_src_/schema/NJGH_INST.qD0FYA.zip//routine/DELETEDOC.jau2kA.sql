create procedure deleteDoc is
begin
  for  i  in (
    select  u.TABLE_NAME from   user_tables  u  where  u.TABLE_NAME  like 'FD%' or  u.TABLE_NAME  like 'RCH%'
    )   loop
     execute immediate 'delete  '|| i.TABLE_NAME;
     commit;
    end loop;
end deleteDoc;

/

