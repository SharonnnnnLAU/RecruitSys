create function getZlCloseTime(pid in integer) return Date is
  result Date;
begin
  select t.close_datetime
    into result
    from (select l.close_datetime
            from BPMDBADEV.lsw_task l
           where l.bpd_instance_id in
                 (select p.processinstanceid
                    from pcc_project p
                   where p.id = pid)
             and l.activity_name in ('??', '????', '????')
           order by l.close_datetime desc) t
   where rownum = 1;
  return(result);
end getZlCloseTime;
/

