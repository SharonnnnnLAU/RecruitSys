create package body DP_APPROVE is

  procedure copydata2(v_id in integer, v_pid in integer) is
    --v_businessId Integer;
    --v_countDoc   Integer;
    --v_doctitle   nvarchar2(2000);
  BEGIN
    for i in (select dm.casecode, --事项编号
                     di.businesstype, --业务类型（正常办理、变更、违章补办、可研）
                     di.casetype, --案件类型
                     di.handletype, --办理类型
                     di.createuserid,
                     di.tempprojecttype, --临时案件类型
                     dm.volumenumber, --卷号
                     dm.roundnumber, --轮次
                     dm.mainorganname, --经办处室名称
                     dm.mainorganid, --经办处室id
                     dm.maindeptid,--科室id
                     dm.maindeptname,--科室
                     dm.municipaltype, --市政类型
                     dm.municipaltype_max,
                     dm.casecategory, --案件类别
                     pb.id as baseid, --项目表id
                     pb.projectname, --项目名称
                     pb.projectcode, --项目编号
                     pb.jsdwmc, --建设单位名称
                     ('南京市' || pb.dz_q || pb.dz_jd || pb.dz_xxdz) as xmdz, --项目地址（拟选址位置）
                     pb.id as pbid,
                     pb.dz_q,
                     pb.dz_jd,
                     pb.dz_xxdz,
                     pb.sfzsdt,
                     pb.sfnmjf,
                     pb.sfsm,
                     pb.gdlx,
                     pb.xmdm,                                        
                     pb.SZFW_DZ,
                     pb.SZFW_XZ,
                     pb.SZFW_NZ,
                     pb.SZFW_BZ,
                     pb.JSDZ,
                     pb.gttdyt
                from bz_declarematterinfo dm
                join bz_declareinfo di
                  on dm.refdeclareid = di.id
                join pdt_projectbase pb
                  on pb.id = di.baseid
               where dm.id = v_id) loop
      update bz_projectcase pc
         set pc.bizid             = i.casecode, --项目编号
             pc.businesstype      = i.businesstype, --业务类型
             pc.casetype          = i.casetype, --案件类型
             pc.handletype        = i.handletype,
             pc.volumenumber      = i.volumenumber, --卷号
             pc.roundnumber       = i.roundnumber, --轮次
             pc.real_volumenumber = i.volumenumber, --卷号
             pc.real_roundnumber  = i.roundnumber, --轮次
             pc.mainorganname     = i.mainorganname, --经办处室名称
             pc.mainorganid       = i.mainorganid, --经办处室id
             pc.municipaltype     = nvl(pc.municipaltype, i.municipaltype), --市政类型
             pc.municipaltype_max = i.municipaltype_max,
             pc.casecategory      = i.casecategory, --案件类别
             pc.baseid            = i.baseid, --项目表id
             pc.projectname       = i.projectname, --项目名称
             pc.projectcode       = i.projectcode, --项目编号
             pc.cbdw              = i.jsdwmc, --承办单位
             pc.casecode          = i.projectcode || i.casecode, --案件编号
             pc.xmdz              = i.xmdz, --项目地址
             pc.nxwz              = i.xmdz, --拟选址位置
             pc.nonregistercaseid = v_id,
             pc.dz_q              = i.dz_q, --地址_区
             pc.dz_jd             = i.dz_jd, --地址_街道
             pc.dz_xxdz           = i.dz_xxdz, --地址_详细地址
             pc.sfzsdt            = i.sfzsdt, --是否增设电梯
             pc.sfnmjf            = i.sfnmjf, --是否农民建房
             pc.sfsm              = i.sfsm, --是否涉密
             pc.tempprojecttype   = i.tempprojecttype, --临时案件类型
             pc.gdlx              = i.gdlx,
             pc.gdfs              = i.gdlx,
             pc.xmdm              = i.xmdm,                       
             pc.DZ_DZ             = nvl(pc.DZ_DZ,i.SZFW_DZ),--东至
             pc.DZ_XZ             = nvl(pc.DZ_XZ,i.SZFW_XZ),--西至
             pc.DZ_NZ             = nvl(pc.DZ_NZ,i.SZFW_NZ),--南至
             pc.DZ_BZ             = nvl(pc.DZ_BZ,i.SZFW_BZ),--北至
             pc.sfbimbj           = (case when instr(i.casetype,'BIM报建')>0 then '是' else '否' end ) --是否BIM报建
       where pc.id in
             (select b.cid from bz_caseinstrelation b where b.pid = v_pid);
      update pcc_project p
         set p.mainorganid   = nvl(i.maindeptid,i.mainorganid),
             p.mainorganname = nvl(i.maindeptname,i.mainorganname),
             p.ownerunitid   = i.mainorganid,
             p.ownerunitname = i.mainorganname,
             p.createuserid  = i.createuserid,
             p.createtype    = decode(p.createtype,'21',p.createtype,decode(i.handletype, '变更', 13, 12))
       where p.id = v_pid;
      update bz_gd_gkcr_tdxx x
         set x.tdyt = i.gttdyt
       where x.cid in 
             (select b.cid from bz_caseinstrelation b where b.pid = v_pid); 
      commit;
      exit;
    end loop;
    --更新项目基本信息表中jsdwmc
    UPDATE BZ_PROJECTCASE C
       SET C.cbdw =
           (SELECT LISTAGG(M.DWMC, ',') WITHIN GROUP(ORDER BY M.DWMC) AS JSDWMC
              FROM BZ_JSDW_XM M
             WHERE M.BASEID = (SELECT C.BASEID
                                 FROM BZ_CASEINSTRELATION T
                                 LEFT JOIN BZ_PROJECTCASE C
                                   ON T.CID = C.ID
                                WHERE T.PID = v_pid))
     WHERE C.ID =
           (SELECT TT.CID FROM BZ_CASEINSTRELATION TT WHERE TT.PID = v_pid);
    --更新受理时间
    UPDATE BZ_PROJECTCASE C
       SET C.ACCEPTTIME =
           (SELECT P.CREATETIME FROM PCC_PROJECT P WHERE P.ID = V_PID)
     WHERE C.ID =
           (SELECT T.CID FROM BZ_CASEINSTRELATION T WHERE T.PID = V_PID)
       AND C.ACCEPTTIME IS NULL;
    --更新申报时间
    UPDATE BZ_PROJECTCASE C
       SET C.SBSJ =
           (SELECT P.CREATETIME FROM PCC_PROJECT P WHERE P.ID = V_PID)
     WHERE C.ID =
           (SELECT T.CID FROM BZ_CASEINSTRELATION T WHERE T.PID = V_PID)
       AND C.SBSJ IS NULL;
    --更新base表中jsdwdmc,jsdwids,bjmrc,bjrids
    UPDATE pdt_PROJECTBASE B
       SET B.Jsdwmc =
           (SELECT LISTAGG(to_char(M.DWMC), ',') WITHIN GROUP(ORDER BY M.DWMC) AS JSDWMC
              FROM BZ_JSDW_XM M
             WHERE M.BASEID = (SELECT C.BASEID
                                 FROM BZ_CASEINSTRELATION T
                                 LEFT JOIN BZ_PROJECTCASE C
                                   ON T.CID = C.ID
                                WHERE T.PID = v_pid)),
           B.jsdwids =
           (SELECT LISTAGG(to_char(M.ID), ',') WITHIN GROUP(ORDER BY M.ID) AS jsdwids
              FROM BZ_JSDW_XM M
             WHERE M.BASEID = (SELECT C.BASEID
                                 FROM BZ_CASEINSTRELATION T
                                 LEFT JOIN BZ_PROJECTCASE C
                                   ON T.CID = C.ID
                                WHERE T.PID = v_pid)),
           B.bjmrc  =
           (SELECT LISTAGG(to_char(M.Bjrmc), ',') WITHIN GROUP(ORDER BY M.Bjrmc) AS Bjrmc
              FROM bz_bjr_xm M
             WHERE M.BASEID = (SELECT C.BASEID
                                 FROM BZ_CASEINSTRELATION T
                                 LEFT JOIN BZ_PROJECTCASE C
                                   ON T.CID = C.ID
                                WHERE T.PID = v_pid)),
           B.bjrids =
           (SELECT LISTAGG(to_char(M.id), ',') WITHIN GROUP(ORDER BY M.id) AS bjrids
              FROM bz_bjr_xm M
             WHERE M.BASEID = (SELECT C.BASEID
                                 FROM BZ_CASEINSTRELATION T
                                 LEFT JOIN BZ_PROJECTCASE C
                                   ON T.CID = C.ID
                                WHERE T.PID = v_pid)),
           B.Bjrdh  =
           (SELECT LISTAGG(to_char(M.Bjryddh), ',') WITHIN GROUP(ORDER BY M.Bjryddh) AS Bjryddh
              FROM bz_bjr_xm M
             WHERE M.BASEID = (SELECT C.BASEID
                                 FROM BZ_CASEINSTRELATION T
                                 LEFT JOIN BZ_PROJECTCASE C
                                   ON T.CID = C.ID
                                WHERE T.PID = v_pid))
     WHERE B.ID = (SELECT C.BASEID
                     FROM BZ_CASEINSTRELATION T
                     LEFT JOIN BZ_PROJECTCASE C
                       ON T.CID = C.ID
                    WHERE T.PID = v_pid);
  
    COMMIT;
  END;

  procedure updateProjectParallelid(pid1 in integer, pid2 in integer) is
  BEGIN
    update pcc_project p
       set p.parallelid = pid2, p.cid = pid2
     where p.id = pid1;
  
    update pcc_project p
       set p.parallelid = pid1, p.cid = pid1
     where p.id = pid2;
    commit;
  END;

  procedure copySupervisionData(v_pid in integer, v_parentId in integer) is
    v_registerdate date;
    v_duetime      date;
    v_shortname    nvarchar2(200);
  BEGIN
    select registerdate
      into v_registerdate
      from pcc_project
     where id = v_parentId;
    select duetime into v_duetime from pcc_project where id = v_parentId;
    select b.shortname
      into v_shortname
      from pcc_project p
      left join njgh_dap.dap_business b
        on p.fk_business_id = b.id
     where p.id = v_parentId;
    update bz_dbhxsj
       set lasj = v_registerdate, jzsj = v_duetime, sxmc = v_shortname
     where pid = v_pid;
    --修改历史案件督办状态
    update pcc_project set supervisestate = 1 where id = v_parentId;
    commit;
  END;

  --
  procedure copyProjectBaseInfo(v_pid in integer, v_ppid in integer) is
    v_pbid     integer;
    v_pbid_new integer;
  BEGIN
    select s_pdt_projectbase.nextval into v_pbid_new from dual;
    select c.baseid
      into v_pbid
      from bz_caseinstrelation ci
      join bz_projectcase c
        on ci.cid = c.id
     where ci.pid = v_ppid;
    --项目基本信息
    insert into pdt_projectbase
      (id,
       projectcode,
       projectname,
       jsdwdm,
       xzqh,
       jsdz,
       zdxm,
       jslx,
       gclx,
       gclxzl,
       xmlx,
       lgdq,
       sfnmjf,
       sfzsdt,
       dz_q,
       dz_jd,
       dz_xxdz,
       gdlx,
       sfsw,
       sfsm,
       jtszxmlx,
       htbh,
       qdrq,
       fwsyq,
       fwcqzh,
       gyr,
       gyqzh,
       zcxzf,
       tdzcqt,
       bz,
       jsdwmc,
       jsdwids,
       bjmrc,
       bjrids,
       zdxm_sj,
       dtjsz,
       dthyz,
       djsj,
       frxm,
       lxrdh,
       lxrmc,
       th,
       tzlx,
       xmbh,
       xmmc,
       xzqs)
      select v_pbid_new,
             projectcode,
             projectname,
             jsdwdm,
             xzqh,
             jsdz,
             zdxm,
             jslx,
             gclx,
             gclxzl,
             xmlx,
             lgdq,
             sfnmjf,
             sfzsdt,
             dz_q,
             dz_jd,
             dz_xxdz,
             gdlx,
             sfsw,
             sfsm,
             jtszxmlx,
             htbh,
             qdrq,
             fwsyq,
             fwcqzh,
             gyr,
             gyqzh,
             zcxzf,
             tdzcqt,
             bz,
             jsdwmc,
             jsdwids,
             bjmrc,
             bjrids,
             zdxm_sj,
             dtjsz,
             dthyz,
             djsj,
             frxm,
             lxrdh,
             lxrmc,
             th,
             tzlx,
             xmbh,
             xmmc,
             xzqs
        from pdt_projectbase pb
       where pb.id = v_pbid;
    --报建人_项目
    insert into bz_bjr_xm
      (id,
       zjlx,
       zjh,
       bjrmc,
       bjrgddh,
       bjryddh,
       gzdw,
       dzyx,
       sfzcghsjzs,
       zjsjb,
       sfljghqk,
       sfjyghbjjl,
       baseid)
      select s_bz_bjr_xm.nextval,
             zjlx,
             zjh,
             bjrmc,
             bjrgddh,
             bjryddh,
             gzdw,
             dzyx,
             sfzcghsjzs,
             zjsjb,
             sfljghqk,
             sfjyghbjjl,
             v_pbid_new
        from bz_bjr_xm bjr
       where bjr.baseid = v_pbid;
  
    --  建设单位_项目
    insert into bz_jsdw_xm
      (id,
       dwmc,
       dwxz,
       jgdm,
       dwdz,
       dwyb,
       frdb,
       frrsfz,
       frdh,
       lxr,
       lxrsfz,
       lxrdh,
       lxrmail,
       lxryb,
       dz_q,
       dz_jd,
       dz_xxdz,
       dwdh,
       czdh,
       gsyyzz,
       zgbm,
       lsgx,
       jjhy,
       jjcf,
       cyml,
       sfwfdckfqy,
       fdckfzz,
       sfylsxmjsjl,
       sfywfjsxw,
       dzyx,
       lsgx_qt,
       dwxz_qt,
       baseid)
      select s_bz_jsdw_xm.nextval,
             dwmc,
             dwxz,
             jgdm,
             dwdz,
             dwyb,
             frdb,
             frrsfz,
             frdh,
             lxr,
             lxrsfz,
             lxrdh,
             lxrmail,
             lxryb,
             dz_q,
             dz_jd,
             dz_xxdz,
             dwdh,
             czdh,
             gsyyzz,
             zgbm,
             lsgx,
             jjhy,
             jjcf,
             cyml,
             sfwfdckfqy,
             fdckfzz,
             sfylsxmjsjl,
             sfywfjsxw,
             dzyx,
             lsgx_qt,
             dwxz_qt,
             v_pbid_new
        from bz_jsdw_xm jsdw
       where jsdw.baseid = v_pbid;
    --土地权属信息
    insert into bz_tdqsxx
      (id,
       syzh,
       tdsyqr,
       wz,
       syqlx,
       dl,
       syqmj,
       fzsj,
       ref_pdt_projectbase_id)
      select s_bz_tdqsxx.nextval,
             syzh,
             tdsyqr,
             wz,
             syqlx,
             dl,
             syqmj,
             fzsj,
             v_pbid_new
        from bz_tdqsxx td
       where td.ref_pdt_projectbase_id = v_pbid;
  
    update bz_projectcase c
       set c.baseid = v_pbid_new
     where c.id in
           (select ci.cid from bz_caseinstrelation ci where ci.pid = v_pid);
    commit;
  END;

  procedure updateQj(mdid in integer) is
    v_requirnum integer;
    v_count     integer;
  begin
    select max(md.requirnum)
      into v_requirnum
      from pcc_materialdirectoryinst md
     where md.id = mdid;
    if (v_requirnum is null) then
      v_requirnum := 0;
    end if;
    select count(*)
      into v_count
      from pcc_materialfile f
     where f.fk_materialdirectoryinst_id = mdid
       and f.correctid is null;
    if v_requirnum <= v_count then
      update pcc_materialdirectoryinst md
         set md.qj = 0, md.dzwj = v_count
       where md.id = mdid;
      commit;
    else
      update pcc_materialdirectoryinst md
         set md.qj = 1, md.dzwj = v_count
       where md.id = mdid;
      commit;
    end if;
  end;

  procedure createWhrwRelation(v_pid     in integer,
                               v_whrwPid in integer,
                               v_type    in varchar2) is
    whrwId integer;
    num    varchar2(100);
  
  begin
    -- select  w.id into whrwId  from   bz_whrw  w  where  w.pid=v_whrwPid;
    whrwId := s_bz_whrw.nextval;
    insert into bz_whrw (id, pid) values (whrwId, v_whrwPid);
    if 'approve' = v_type then
      select c.casecode
        into num
        from bz_projectcase c
        join bz_caseinstrelation cr
          on c.id = cr.cid
       where cr.pid = v_pid;
    else
      --select max(d.docnum)
      select max(decode(d.doctype, '发文', d.fwlsh, d.docnum))
        into num
        from njoa_inst.fd_doc d
       where d.docid = v_pid;
    end if;
    insert into bz_whrw_relation
      (id, fk_whrw_id, pid, type)
    values
      (s_bz_whrw_relation.nextval, whrwId, v_pid, v_type);
    update bz_whrw w
       set w.xtmc = decode(v_type, 'doc', '行政办公系统', '规划实施系统'),
           w.bh   = num
     where w.id = whrwId;
    commit;
  
  end;

  procedure createWhrwRelation2(v_pid     in integer,
                                v_whrwPid in integer,
                                v_type    in varchar2) is
    whrwId  integer;
    v_count integer;
  
  begin
    select w.id into whrwId from bz_whrw w where w.pid = v_whrwPid;
    select count(*)
      into v_count
      from bz_whrw_relation wr
     where wr.fk_whrw_id = whrwId;
    if (v_count > 0) then
      update bz_whrw_relation wr
         set wr.pid = v_pid, wr.type = v_type
       where wr.fk_whrw_id = whrwId;
    else
      insert into bz_whrw_relation
        (id, fk_whrw_id, pid, type)
      values
        (s_bz_whrw_relation.nextval, whrwId, v_pid, v_type);
    end if;
    commit;
  end;

  procedure getWhrwRelationInfo(v_pid      in integer,
                                ref_cursor out sys_refcursor) is
    v_type        varchar2(100);
    v_relationPid integer;
    v_whlsh       varchar2(100);
  begin
    select max(wr.pid), max(wr.type), max(sl.sllsh)
      into v_relationPid, v_type, v_whlsh
      from bz_whrw w
      join bz_whrw_relation wr
        on w.id = wr.fk_whrw_id
      join bz_slxx sl
        on sl.pid = w.pid
     where w.pid = v_pid;
    if ('doc' = v_type) then
      open ref_cursor for
        select p.id           as pid,
               p.subtype,
               p.businessname,
               t.id           as taskid,
               v_type         as type,
               v_whlsh        as whlsh
          from njoa_inst.pcc_project p
          join njoa_inst.fd_doctask t
            on p.id = t.pid
         where p.id = v_relationPid
           and t.id = (select max(dt.id)
                         from njoa_inst.fd_doctask dt
                        where dt.pid = v_relationPid);
    else
      open ref_cursor for
        select p.id as pid, p.subtype, p.businessname
          from pcc_project p
        /*join BPMDB_TEST.lsw_task t
        on p.processinstanceid = t.bpd_instance_id*/
         where p.id = v_relationPid;
      /*and t.task_id =
      (select max(l.task_id)
         from BPMDB_TEST.lsw_task l
        where l.bpd_instance_id = p.processinstanceid);*/
    end if;
  end;
  procedure createRootMaterialDirectory(v_pid                in integer,
                                        v_directoryName      in varchar2,
                                        v_childDirectoryName in varchar2) is
    v_parentId integer;
    v_mcid     integer;
  begin
    v_parentId := s_pcc_materialdirectoryinst.nextval;
    select mc.id
      into v_mcid
      from pcc_materialcategoryinst mc
     where mc.refid = v_pid;
    insert into pcc_materialdirectoryinst
      (discriminator,
       id,
       contained,
       containnum,
       directoryname,
       fk_materialcategoryinst_id,
       override,
       required,
       requirnum)
    values
      ('base', v_parentId, 1, 0, v_directoryName, v_mcid, 1, 0, 1);
    if v_childDirectoryName is not null then
      insert into pcc_materialdirectoryinst
        (discriminator,
         id,
         contained,
         containnum,
         directoryname,
         fk_materialcategoryinst_id,
         override,
         parentid,
         required,
         requirnum)
      values
        ('base',
         s_pcc_materialdirectoryinst.nextval,
         1,
         0,
         v_directoryName,
         v_mcid,
         1,
         v_parentid,
         0,
         1);
    end if;
    commit;
  end;

  procedure updateProjectCode1(v_pid in integer, v_projectCode in varchar2) is
    v_parallelid integer;
  begin
    DP_Approve.updateProjectCode2(v_pid, v_projectCode);
    select max(p.parallelid)
      into v_parallelid
      from pcc_project p
     where p.id = v_pid;
    if (v_parallelid is not null) then
      DP_Approve.updateProjectCode2(v_parallelid, v_projectCode);
    end if;
  end;
  procedure updateProjectCode2(v_pid in integer, v_projectCode in varchar2) is
    v_cid    integer;
    v_baseid integer;
  begin
    --  update  pdt_projectbase  b  set  b.projectcode=v_projectCode  where  b.
    select c.baseid, c.id
      into v_baseid, v_cid
      from bz_caseinstrelation ci
      join bz_projectcase c
        on ci.cid = c.id
     where ci.pid = v_pid;
    update bz_projectcase c
       set c.projectcode = v_projectCode,
           c.casecode    = v_projectCode || c.bizid
     where c.id = v_cid;
    update pdt_projectbase b
       set b.projectcode = v_projectCode
     where b.id = v_baseid;
    commit;
  
  end;

  procedure updateProjectCode3(v_projectCode in varchar2) is
  begin
    for i in (select distinct pa.pid
                from pcc_ParallelApprove pa
                left join pcc_project t
                  on t.id = pa.pid
               where t.id is not null
                 and pa.projectcode = v_projectCode) loop
      DP_Approve.updateProjectCode2(i.pid, v_projectCode);
    
    end loop;
  end;

  procedure updateProjectCaseInfo(v_pid   in integer,
                                  v_pbid  in integer,
                                  v_bizid in varchar2) is
    v_cid integer;
  begin
    select max(cr.cid)
      into v_cid
      from bz_caseinstrelation cr
     where cr.pid = v_pid;
    if (v_cid is not null) then
      for i in (select pb.id as baseid, --项目表id
                       pb.projectname, --项目名称
                       pb.projectcode, --项目编号
                       pb.jsdwmc, --建设单位名称
                       ('南京市'|| pb.dz_q || pb.dz_jd || pb.dz_xxdz) as xmdz, --项目地址（拟选址位置）
                       pb.id as pbid,
                       pb.dz_q,
                       pb.dz_jd,
                       pb.dz_xxdz,
                       pb.sfzsdt
                  from pdt_projectbase pb
                 where pb.id = v_pbid
                   and rownum = 1) loop
        update bz_projectcase pc
           set pc.projectname = i.projectname, --项目名称
               --pc.projectcode = i.projectcode, --项目编号
               pc.cbdw = i.jsdwmc, --承办单位
               --   pc.casecode          = i.projectcode || v_bizid, --案件编号
               pc.xmdz    = i.xmdz, --项目地址
               pc.nxwz    = i.xmdz, --拟选址位置
               pc.dz_q    = i.dz_q, --地址_区
               pc.dz_jd   = i.dz_jd, --地址_街道
               pc.dz_xxdz = i.dz_xxdz, --地址_详细地址
               pc.sfzsdt  = i.sfzsdt --是否增设电梯
         where pc.id = v_cid;
      end loop;
    else
      v_cid := s_bz_projectcase.nextval;
      insert into bz_caseinstrelation
        (id, pid, cid)
      values
        (s_bz_caseinstrelation.nextval, v_pid, v_cid);
      insert into bz_projectcase
        (id,
         baseid,
         bizid,
         projectname,
         projectcode,
         cbdw,
         nxwz,
         xmdz,
         casecode,
         dz_q,
         dz_jd,
         dz_xxdz,
         sfzsdt)
        select v_cid,
               pb.id as baseid, --项目表id
               v_bizid,
               pb.projectname, --项目名称
               pb.projectcode, --项目编号
               pb.jsdwmc, --建设单位名称
               (pb.dz_q || pb.dz_jd || pb.dz_xxdz) as xmdz, --项目地址（拟选址位置）
               (pb.dz_q || pb.dz_jd || pb.dz_xxdz) as xmdz, --项目地址（拟选址位置）
               pb.projectcode || v_bizid,
               pb.dz_q,
               pb.dz_jd,
               pb.dz_xxdz,
               pb.sfzsdt
          from pdt_projectbase pb
         where pb.id = v_pbid
           and rownum = 1;
    end if;
    commit;
  end;

  procedure deleteDkmxAndXzmx(v_Cid in integer) is
  begin
    delete BZ_YD_JS_DKMX b where b.cid = v_Cid;
    delete BZ_YD_DZ_DKMX b where b.cid = v_Cid;
    delete BZ_YD_DZ_XZMX b where b.cid = v_Cid;
    delete BZ_YD_JS_XZMX b where b.cid = v_Cid;
    update bz_ghtj_jzqyszt g
       set g.gy_ydmj_zyd   = '', --概要_用地面积_总用地
           g.gy_ydmj_kjsyd = '', --概要_用地面积_可建设用地
           g.gy_ydmj_dzld  = '', --概要_用地面积_代征绿地
           g.gy_ydmj_dzhd  = '', --概要_用地面积_代征河道
           g.gy_ydmj_dzdl  = '', --概要_用地面积_代征道路
           g.gy_ydmj_dzgg  = '', --概要_用地面积_代征公共
           g.gy_ydmj_dzyd  = '' -- 概要_用地面积_代征用地
     where g.cid = v_Cid;
    commit;
  end;

  function get_ghhs_gcxkzh(v_cid in integer) return varchar2 is
    result varchar(500);
  begin
    select to_char(wm_concat(to_char(i.xkzh))) as gcxkz
      into result
      from (select b.xkzh
              from bz_jzyxspb b
             where b.scjg = '符合'
               and b.cid = v_cid
             group by b.xkzh) i;
  
    return(result);
  end;

  procedure deleteDataBeforeImportBSTJQD(v_cid in integer) is
  begin
    delete bz_sbcl b
     where b.cid = v_cid
       and b.cllb is null;
    delete BZ_JNCL b
     where b.cid = v_cid
       and nvl(b.type, '--') != '受理通知书';
  end;

  procedure deleteDataBeforeImportBGXX(v_cid in integer) is
  
  begin
    delete bz_sbcl b
     where b.cid = v_cid
       and b.cllb is not null;
    delete bz_bg_bgsx b where b.cid = v_cid;
    delete bz_bg_bgxx b where b.cid = v_cid;
  end;

  procedure deleteDeclareProject(v_dmid in integer) is
    v_cid    integer;
    v_pid    integer;
    v_baseid integer;
    v_did    integer;
  begin
    select m.refdeclareid
      into v_did
      from bz_declarematterinfo m
     where m.id = v_dmid;
    if v_did is null then
      return;
    end if;
    select max(c.id), max(cr.pid), max(c.baseid)
      into v_cid, v_pid, v_baseid
      from bz_projectcase c
      join bz_caseinstrelation cr
        on cr.cid = c.id
     where c.ref_declarematterinfo_id = v_dmid;
  
    --删除申报信息
    delete bz_declareinfo b where b.id = v_did;
  
    ---删除申报事项信息
    delete bz_declarematterinfo dmi where dmi.refdeclareid = v_did;
  
    ---删除审批事项信息
    delete pcc_project p where p.id = v_pid;
  
    ---删除并联关系消息
    delete pcc_parallelapprove pa
     where pa.pid = v_pid
        or pa.parallelpid = v_pid;
  
    ---删除证书信息
    delete bz_zsxx x where x.cid = v_cid;
  
    ---删除项目信息
    delete pdt_projectbase pb where pb.id = v_baseid;
  
    ---删除关联信息
    delete bz_caseinstrelation cr where cr.cid = v_cid;
    --删除案件信息
    delete bz_projectcase c where c.baseid = v_baseid;
    commit;
  end;

  procedure deleteJZVerifyDataByCid(v_cid in integer) is
  
  begin
    delete BZ_FA_DKHJ where cid = v_cid;
    delete BZ_FA_DK where cid = v_cid;
    delete BZ_FA_JZW_D where cid = v_cid;
    delete BZ_FA_JZW_C where cid = v_cid;
    delete BZ_FAGC_JZXX where cid = v_cid;
    delete BZ_FA_JZWGN_D where cid = v_cid;
    delete BZ_FA_JZWGN_C where cid = v_cid;
    delete BZ_FAGC_JZYTXXXX where cid = v_cid;
    delete BZ_LDHXXX where cid = v_cid;
    commit;
  end;

  procedure resetProjectCode(v_pid in integer, v_projectCode in varchar2) is
    v_cid    integer;
    v_baseId integer;
  begin
    select v.cid, v.baseId
      into v_cid, v_baseId
      from v_projectcaseinfo v
     where v.pid = v_pid;
    update bz_projectcase c
       set c.projectcode = v_projectCode,
           c.casecode    = v_projectCode || c.bizid
     where c.id = v_cid;
    update pdt_projectbase b
       set b.projectcode = v_projectCode
     where b.id = v_baseId;
    commit;
  end;

  --续办复制pdt_projectbase数据
  PROCEDURE copyDataBase(OLDBASEID IN INTEGER, NEWBASEID IN INTEGER) IS
  BEGIN
    --基本信息
    for i in (SELECT PROJECTNAME,
                     PROJECTCODE,
                     JSDWMC,
                     XMLX,
                     DZ_Q,
                     DZ_JD,
                     DZ_XXDZ,
                     XMDM,
                     CSTXDW,
                     ZDXM,
                     GDLX,
                     SFBL,
                     SFJYJSXM,
                     SFSM,
                     SFSW,
                     JTSZXMLX,
                     LXBM,
                     LXLX,
                     PZWH,
                     LXPZSJ,
                     XMLY,
                     ZJLY,
                     TZGM,
                     TZGMSM,
                     GCJSZQQ,
                     GCJSZQZ,
                     YDMJ,
                     ZJZMJ,
                     HYLB,
                     GTTDYT,
                     XMJSYJ,
                     SZFW_DZ,
                     SZFW_XZ,
                     SZFW_NZ,
                     SZFW_BZ,
                     JSDZ
                FROM PDT_PROJECTBASE
               WHERE ID = OLDBASEID) loop
      update pdt_projectbase pc
         set pc.projectname = i.projectname, --项目名称
             pc.projectcode = i.projectcode, --项目编号  
             pc.JSDWMC      = i.jsdwmc, --承办单位
             pc.xmlx        = i.xmlx, --项目类型
             pc.dz_q        = i.dz_q, --地址_区
             pc.dz_jd       = i.dz_jd, --地址_街道
             pc.dz_xxdz     = i.dz_xxdz, --地址_详细地址
             pc.XMDM        = i.XMDM, --项目代码
             pc.CSTXDW      = i.CSTXDW, --初始图形位置
             pc.zdxm        = i.zdxm, --是否重点项目
             pc.gdlx        = i.gdlx, --供地类型
             pc.sfbl        = i.sfbl, --是否并联
             pc.sfjyjsxm    = i.sfjyjsxm, --是否简易建设项目
             pc.sfsm        = i.sfsm, --是否涉密
             pc.sfsw        = i.sfsw, --是否涉外
             pc.JTSZXMLX    = i.JTSZXMLX, --交通市政类型
             pc.LXBM        = i.LXBM, --立项部门
             pc.LXLX        = i.LXLX, --立项类型
             pc.PZWH        = i.PZWH, --批准文号
             pc.LXPZSJ      = i.LXPZSJ, --批准时间
             pc.XMLY        = i.XMLY, --项目来源
             pc.ZJLY        = i.ZJLY, --资金来源
             pc.TZGM        = i.TZGM, --投资规模
             pc.TZGMSM      = i.TZGMSM, --投资规模说明
             pc.GCJSZQQ     = i.GCJSZQQ, --工程建设周期起时间
             pc.GCJSZQZ     = i.GCJSZQZ, --工程建设周期止时间
             pc.YDMJ        = i.YDMJ, --用地面积
             pc.ZJZMJ       = i.ZJZMJ, --总建筑面积
             pc.HYLB        = i.HYLB, --行业类别
             pc.GTTDYT      = i.GTTDYT, --土地用途
             pc.Xmjsyj      = i.XMJSYJ, --项目依据
             pc.SZFW_DZ     = i.SZFW_DZ,--东至
             pc.SZFW_XZ     = i.SZFW_XZ,--西至
             pc.SZFW_NZ     = i.SZFW_NZ,--南至
             pc.SZFW_BZ     = i.SZFW_BZ,--北至
             pc.JSDZ        = i.JSDZ    --建设地址
       where pc.id = NEWBASEID;
    end loop;
    --????baseId  ????????
    INSERT INTO BZ_JSDW_XM JX
      (JX.ID,
       JX.DWMC,
       JX.DWXZ,
       JX.DZ_XXDZ,
       JX.TYSHXYDM,
       JX.JGDM,
       JX.FRDB,
       JX.DWXMFZR,
       JX.FRZJLX,
       JX.FRRSFZ,
       JX.XZXDRLB,
       JX.BASEID)
      SELECT S_BZ_JSDW_XM.NEXTVAL,
             JSDW.DWMC,
             JSDW.DWXZ,
             JSDW.DZ_XXDZ,
             JSDW.TYSHXYDM,
             JSDW.JGDM,
             JSDW.FRDB,
             JSDW.DWXMFZR,
             JSDW.FRZJLX,
             JSDW.FRRSFZ,
             JSDW.XZXDRLB,
             NEWBASEID
        FROM BZ_JSDW_XM JSDW
       WHERE JSDW.BASEID = OLDBASEID;
  
    --??????
    INSERT INTO bz_bjr_xm bjr
      (bjr.ID, bjr.bjrmc, bjr.bjryddh, bjr.zjlx, bjr.zjh, bjr.BASEID)
      SELECT s_bz_bjr_xm.NEXTVAL,
             bj.bjrmc,
             bj.bjryddh,
             bj.zjlx,
             bj.zjh,
             NEWBASEID
        FROM bz_bjr_xm bj
       WHERE bj.BASEID = OLDBASEID;
    COMMIT;
  END;

  procedure copyBaseToCase(v_baseId in integer, v_pid in integer) is
  begin
    for i in (select pb.id as baseid, --项目表id
                     pb.projectname, --项目名称
                     pb.projectcode, --项目编号
                     pb.jsdwmc, --建设单位名称
                     ('南京市'|| pb.dz_q || pb.dz_jd || pb.dz_xxdz) as xmdz, --项目地址（拟选址位置）
                     pb.id as pbid,
                     pb.dz_q,
                     pb.dz_jd,
                     pb.dz_xxdz,
                     pb.sfzsdt,
                     pb.sfnmjf,
                     pb.sfsm,
                     pb.gdlx,
                     pb.xmdm
                from pdt_projectbase pb
               where pb.id = v_baseId) loop
      update bz_projectcase pc
         set pc.baseid      = i.baseid, --项目表id
             pc.projectname = i.projectname, --项目名称
             pc.projectcode = i.projectcode, --项目编号
             pc.cbdw        = i.jsdwmc, --承办单位
             pc.casecode    = i.projectcode, --案件编号
             pc.xmdz        = i.xmdz, --项目地址
             pc.nxwz        = i.xmdz, --拟选址位置
             pc.dz_q        = i.dz_q, --地址_区
             pc.dz_jd       = i.dz_jd, --地址_街道
             pc.dz_xxdz     = i.dz_xxdz, --地址_详细地址
             pc.sfzsdt      = i.sfzsdt, --是否增设电梯
             pc.sfnmjf      = i.sfnmjf, --是否农民建房
             pc.sfsm        = i.sfsm, --是否涉密
             pc.gdlx        = i.gdlx,
             pc.xmdm        = i.xmdm
       where pc.id in
             (select b.cid from bz_caseinstrelation b where b.pid = v_pid);
      commit;
    end loop;
  end;
  
  --在办箱：复制bz_projectcase数据到pdt_projectbase
  procedure copyCaseToBase(v_pid in integer, v_baseId in integer) is
  begin
    for i in (select c.bizid, --项目编号
                    c.baseid, --项目表id
                    c.projectname, --项目名称
                    c.projectcode, --项目编号
                    c.cbdw, --承办单位
                    c.casecode, --案件编号
                    c.xmdz, --项目地址
                    c.nxwz, --拟选址位置
                    c.dz_q, --地址_区
                    c.dz_jd, --地址_街道
                    c.dz_xxdz, --地址_详细地址
                    c.sfzsdt, --是否增设电梯
                    c.sfnmjf, --是否农民建房
                    c.sfsm, --是否涉密
                    c.gdlx,
                    c.gdfs,
                    c.xmdm,                       
                    c.DZ_DZ,--东至
                    c.DZ_XZ,--西至
                    c.DZ_NZ,--南至
                    c.DZ_BZ,--北至 
                    x.tdyt
               from bz_projectcase c
          left join bz_gd_gkcr_tdxx x on x.cid = c.id  
              where c.id in
                  (select b.cid from bz_caseinstrelation b where b.pid = v_pid)) loop
      update pdt_projectbase pb
         set pb.projectname = i.projectname, --项目名称
             pb.projectcode = i.projectcode, --项目编号
             pb.jsdwmc      = i.cbdw, --承办单位
             pb.dz_q        = i.dz_q, --地址_区
             pb.dz_jd       = i.dz_jd, --地址_街道
             pb.dz_xxdz     = i.dz_xxdz, --地址_详细地址
             pb.sfzsdt      = i.sfzsdt, --是否增设电梯
             pb.sfnmjf      = i.sfnmjf, --是否农民建房
             pb.sfsm        = i.sfsm, --是否涉密
             pb.gdlx        = i.gdlx,
             pb.xmdm        = i.xmdm,
             pb.SZFW_DZ     = i.DZ_DZ,
             pb.SZFW_XZ     = i.DZ_XZ,
             pb.SZFW_NZ     = i.DZ_NZ,
             pb.SZFW_BZ     = i.DZ_BZ,
             pb.gttdyt      = i.tdyt
       where pb.id = v_baseId;
      commit;
    end loop;
  end;
  
  procedure updateYbProjectCodeAndCaseCode(v_pid in integer, v_projectCode in varchar2, v_caseCode in varchar2, v_bizId in varchar2) is
    v_cid    integer;
    v_baseid integer;
  begin
    select c.baseid, c.id
      into v_baseid, v_cid
      from bz_caseinstrelation ci
      join bz_projectcase c
        on ci.cid = c.id
     where ci.pid = v_pid;
     
    update bz_projectcase c
       set c.projectcode = v_projectCode,
           c.casecode    = v_caseCode,
           c.bizid = v_bizId
     where c.id = v_cid;
      commit;
    update pdt_projectbase b
       set b.projectcode = v_projectCode
     where b.id = v_baseid;
    commit;
    update bz_declarematterinfo dm set dm.casecode=v_bizId,dm.volumenumber=1,dm.roundnumber=1
    where dm.id in (
      select d.id from bz_declarematterinfo d 
      left join bz_declareinfo di on di.id=d.refdeclareid
      left join bz_projectcase pc on pc.baseid=di.baseid
      left join bz_caseinstrelation cr on cr.cid=pc.id
      where cr.pid=v_pid
    );
     commit;
  end;
  
  --更新勘测定界字段来保存全要素勘测定界信息
  procedure updateQysKCDJInfo(v_pid    in integer,
                              v_jbr    in varchar2,
                              v_jbrq   in timestamp,
                              v_kcdw   in varchar2,
                              v_kcdjyq in varchar2) is
    v_cid integer;
  begin
    select c.id
      into v_cid
      from bz_caseinstrelation cr
      join bz_projectcase c
        on cr.cid = c.id
     where cr.pid = v_pid;
  
    update bz_jssc s
       set s.kcdw   = v_kcdw,
           s.jbr    = v_jbr,
           s.sjrq   = v_jbrq,
           s.kcdjyq = v_kcdjyq
     where s.cid = v_cid;
    commit;
  
    /* update bz_kcdj k
       set k.kcdjyq = v_kcdjyq, k.qs = v_kcdw
     where k.cid = v_cid;
    commit;*/
  end;

end DP_APPROVE;
/

