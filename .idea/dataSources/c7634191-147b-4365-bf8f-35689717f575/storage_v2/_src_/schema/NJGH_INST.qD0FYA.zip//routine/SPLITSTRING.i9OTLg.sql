create function splitString(v_string  in varchar2,
                                       v_delimer in varchar2 := ',')
  return varchar2 is

  result varchar2(2000);

begin


  if instr(v_string, v_delimer) = 0 then
    --????????????????
    return v_string;

  else
    --?????????????????????
    return substr(v_string, 0, (instr(v_string, v_delimer) - 1));

  end if;

  return(result);

end splitString;
/

