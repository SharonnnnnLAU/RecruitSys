create function connectColbFiledByPid(v_pid in integer)
  return clob is
  result clob;
begin

  for i in (select nn.yj
              from bz_caseinstrelation n
              left join bz_opinion nn
                on n.cid = nn.cid
             where n.pid = v_pid) loop
    result := result || i.yj;
  end loop;

  return(result);
end connectColbFiledByPid;
/

