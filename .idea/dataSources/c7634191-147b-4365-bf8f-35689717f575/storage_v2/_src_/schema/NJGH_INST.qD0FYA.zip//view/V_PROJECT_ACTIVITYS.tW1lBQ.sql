create view V_PROJECT_ACTIVITYS as
select p.id as pid,
       p.processinstanceid,
       to_char(wm_concat(to_char(l.activity_name)))  as activityname
  from pcc_project p
  join BPMDBADEV.Lsw_Task l
    on p.processinstanceid = l.bpd_instance_id
 where l.status in (11, 12)
 group by p.id, p.processinstanceid
/

