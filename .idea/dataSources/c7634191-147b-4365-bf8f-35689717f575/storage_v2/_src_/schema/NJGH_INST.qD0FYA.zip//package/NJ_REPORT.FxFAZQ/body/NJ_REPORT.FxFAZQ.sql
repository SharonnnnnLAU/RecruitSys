create package body NJ_REPORT is

  procedure Test(rzttable out rq_cursor,v_pid integer) is
    a varchar2(2000);
  begin

    open rzttable for

select p.id,n.cid, nvl2(e.PTSS_GGLD||e.PTSS_JZSQZX||e.PTSS_JCSQZX||e.PTSS_QT,1,0) AS V32,  nvl2(e.PTSS_SZ,1,0) as V33,
           nvl2(e.WB,1,0) as V4 ,
           nvl2(f.GXJFSSS_ZT,1,0) as V51,  nvl2(f.GXJFSSS_XJ,1,0) as V52,  /*nvl2(f.GXJFSSS_SS,1,0)*/1 as V53,  nvl2(f.GXJFSSS_PS,1,0) as V54, nvl2(f.GXJFSSS_HMCSYQ,1,nvl2(f.DTSTYQ_ZX_HMCSNLLKZL,1,nvl2(f.DTSTYQ_ZX_HMCSMYWRXJL,1,0))) as V55,
           nvl2(e.JTYQ_TCPJ_CDSHYQ||e.JTYQ_TCPJ_YZYQ,1,0) as V61,  nvl2(e.JTYQ_CRK,1,0) as V62,  nvl2(e.JTYQ_DK,1,0) as V63,  nvl2(e.JTYQ_QT,1,0) as V64,
           nvl2(e.CSSJYQ_ZT,1,0) as V71,  nvl2(e.CSSJYQ_KJXT,1,0) as V72,  nvl2(e.CSSJYQ_JQKZ,1,0) as V73,  nvl2(e.CSSJYQ_JZFG,1,0) as V74,  nvl2(e.CSSJYQ_JGZM,1,0) as V75,  nvl2(e.CSSJYQ_WQSZ,1,0) as V76,  nvl2(e.CSSJYQ_QT,1,0) as V77,
           nvl2(e.DXKJYQ,1,0) as V8,
           nvl2(e.JZSJYQ_ZT,1,0) as V91,  nvl2(e.JZSJYQ_DPBG,1,0) as V92,  nvl2(e.JZSJYQ_JZTR,1,0) as V93,  nvl2(e.JZSJYQ_JZJJ,1,0) as V94, nvl2(e.JZSJYQ_FSSS,1,0) as V95, nvl2(e.JZSJYQ_QT,1,0) as V96,
           nvl2(e.GHBHYQ_JQ,1,0) as V101,  nvl2(e.GHBHYQ_GDJT,1,0) as V102,  nvl2(e.GHBHYQ_DLDX,1,0) as V103,  nvl2(e.GHBHYQ_HD,1,0) as V104,  nvl2(e.GHBHYQ_CLBZ,1,0) as V105,  nvl2(e.GHBHYQ_LBSS,1,0) as V106,  nvl2(e.GHBHYQ_STHX,1,0) as V107,  nvl2(e.GHBHYQ_SDBHYQ,1,0) as V108,nvl2(e.GHBHYQ_QT,1,0) as V109,
           nvl2(e.DTSTYQ_ZT,1,0) as V111, nvl2(e.DTSTYQ_ZX,1,0) as V112,
           nvl2(e.BSYQ_JZ,1,0) AS V12,
           1 as V131, nvl2(e.BSYQ_JZ,1,0) as V132,  nvl2(f.BSYQ_GX,1,0) as V133,
           nvl2(to_char(e.FJ),1,0) as V14 ,to_char(e.FJ) V14A,
           DBMS_LOB.GETLENGTH(e.BZ) as V15

    from bz_caseinstrelation n
    inner join pcc_project p on p.id = n.pid
    left join BZ_GHTJ_JZQYSZT e on n.cid = e.cid
    left join BZ_GHTJ_SZQYSZT f on n.cid = f.cid
    where p.id=v_pid;
  end Test;

  -- 分隔形成子表
  function Split(str in varchar2, delimiter varchar2) return str_table is
      psrc VARCHAR2(1000);
      tab str_table := str_table();
      i number := 1;
      j number := 1;
  begin
       psrc := str;
       psrc := RTrim(LTrim(psrc, delimiter), delimiter);

       loop
           i := InStr(psrc, delimiter, j);
           if i>0 then
               tab.extend;
               tab(tab.Count) := Trim(SubStr(psrc, j, i-j));
               j := i+1;
           end if;
           exit when i=0;
       end loop;
       if j < Length(psrc) then
          tab.extend;
          tab(tab.Count) := Trim(SubStr(psrc, j, Length(psrc)+1-j));
       end if;

       return tab;
  end Split;

  --计算行编号
  function CalcRowNum(cnt in integer,valueTab in out num_table,rowNum in integer,hasRow out boolean) return num_table is
      clmNum number(8,2) :=0;
      i integer :=1;
  begin
      hasRow := false;
      while i<=cnt loop
          if valueTab(i) >0 then
             clmNum := clmNum + 0.1;
             valueTab(i) := rowNum + clmNum;
             hasRow := true;
          else
             valueTab(i) := 0;
          end if;
          i := i+1;
      end loop;
      return num_table();
  end  CalcRowNum;

  --全要素章节编号值
  procedure GetNumOfQYS(numtable out rq_cursor,v_pid in integer,jzOrSZ in integer) is
      i integer;
      curNum NUMBER(8,2);
      vTab num_table;
      fTab num_table;
      hasRow boolean ;
        F32 NUMBER(8,2) :=0 ;  V32 Integer;
        F33 NUMBER(8,2) :=0 ;  V33 Integer;
      F4 NUMBER(8,2) :=0 ;     V4  Integer;
      F5 NUMBER(8,2) :=0 ;
        F51 NUMBER(8,2) :=0 ;  V51 Integer;
        F52 NUMBER(8,2) :=0 ;  V52 Integer;
        F53 NUMBER(8,2) :=0 ;  V53 Integer;
        F54 NUMBER(8,2) :=0 ;  V54 Integer;
        F55 NUMBER(8,2) :=0 ;  V55 Integer;
      F6 NUMBER(8,2) :=0 ;
        F61 NUMBER(8,2) :=0 ;  V61 Integer;
        F62 NUMBER(8,2) :=0 ;  V62 Integer;
        F63 NUMBER(8,2) :=0 ;  V63 Integer;
        F64 NUMBER(8,2) :=0 ;  V64 Integer;
      F7 NUMBER(8,2) :=0 ;
        F71 NUMBER(8,2) :=0 ;  V71 Integer;
        F72 NUMBER(8,2) :=0 ;  V72 Integer;
        F73 NUMBER(8,2) :=0 ;  V73 Integer;
        F74 NUMBER(8,2) :=0 ;  V74 Integer;
        F75 NUMBER(8,2) :=0 ;  V75 Integer;
        F76 NUMBER(8,2) :=0 ;  V76 Integer;
        F77 NUMBER(8,2) :=0 ;  V77 Integer;
      F8 NUMBER(8,2) :=0 ;     V8  Integer;
      F9 NUMBER(8,2) :=0 ;
        F91 NUMBER(8,2) :=0 ;  V91 Integer;
        F92 NUMBER(8,2) :=0 ;  V92 Integer;
        F93 NUMBER(8,2) :=0 ;  V93 Integer;
        F94 NUMBER(8,2) :=0 ;  V94 Integer;
        F95 NUMBER(8,2) :=0 ;  V95 Integer;
        F96 NUMBER(8,2) :=0 ;  V96 Integer;
      F10 NUMBER(8,2) :=0 ;
        F101 NUMBER(8,2) :=0 ; V101 Integer;
        F102 NUMBER(8,2) :=0 ; V102 Integer;
        F103 NUMBER(8,2) :=0 ; V103 Integer;
        F104 NUMBER(8,2) :=0 ; V104 Integer;
        F105 NUMBER(8,2) :=0 ; V105 Integer;
        F106 NUMBER(8,2) :=0 ; V106 Integer;
        F107 NUMBER(8,2) :=0 ; V107 Integer;
        F108 NUMBER(8,2) :=0 ; V108 Integer;
        F109 NUMBER(8,2) :=0 ; V109 Integer;
      F11 NUMBER(8,2) :=0 ;
        F111 NUMBER(8,2) :=0 ; V111 Integer;
        F112 NUMBER(8,2) :=0 ; V112 Integer;
      F12 NUMBER(8,2) :=0 ;    V12  Integer;
      F13 NUMBER(8,2) :=0 ;
        F131 NUMBER(8,2) :=0 ; V131 Integer;
        F132 NUMBER(8,2) :=0 ; V132 Integer;
        F133 NUMBER(8,2) :=0 ; V133 Integer;
      F14 NUMBER(8,2) :=0 ;    V14 Integer;
      F15 NUMBER(8,2) :=0 ;    V15 Integer;
  begin
    /*
    select nvl2(e.PTSS_GG,1,0) AS V32,  nvl2(e.PTSS_SZ,1,0) as V33,
           nvl2(e.WB,1,0) as V4 ,
           nvl2(f.GXJFSSS_ZT,1,0) as V51,  nvl2(f.GXJFSSS_XJ,1,0) as V52,  /   *nvl2(f.GXJFSSS_SS,1,0)*   /1 as V53,  nvl2(f.GXJFSSS_PS,1,0) as V54,
           nvl2(e.JTYQ_TCPJ_CDSHYQ||e.JTYQ_TCPJ_YZYQ,1,0) as V61,  nvl2(e.JTYQ_CRK,1,0) as V62,  nvl2(e.JTYQ_DK,1,0) as V63,  nvl2(e.JTYQ_QT,1,0) as V64,
           nvl2(e.CSSJYQ_ZT,1,0) as V71,  nvl2(e.CSSJYQ_KJXT,1,0) as V72,  nvl2(e.CSSJYQ_JQKZ,1,0) as V73,  nvl2(e.CSSJYQ_JZFG,1,0) as V74,  nvl2(e.CSSJYQ_JGZM,1,0) as V75,  nvl2(e.CSSJYQ_WQSZ,1,0) as V76,  nvl2(e.CSSJYQ_QT,1,0) as V77,
           nvl2(e.DXKJYQ,1,0) as V8,
           nvl2(e.JZSJYQ_ZT,1,0) as V91,  nvl2(e.JZSJYQ_DPBG,1,0) as V92,  nvl2(e.JZSJYQ_JZTR,1,0) as V93,  nvl2(e.JZSJYQ_JZJJ,1,0) as V94, nvl2(e.JZSJYQ_FSSS,1,0) as V95, nvl2(e.JZSJYQ_QT,1,0) as V96,
           nvl2(e.GHBHYQ_JQ,1,0) as V101,  nvl2(e.GHBHYQ_GDJT,1,0) as V102,  nvl2(e.GHBHYQ_DLDX,1,0) as V103,  nvl2(e.GHBHYQ_HD,1,0) as V104,  nvl2(e.GHBHYQ_CLBZ,1,0) as V105,  nvl2(e.GHBHYQ_LBSS,1,0) as V106,  nvl2(e.GHBHYQ_STHX,1,0) as V107,  nvl2(e.GHBHYQ_QT,1,0) as V108,
           nvl2(e.DTSTYQ_ZT,1,0) as V111, nvl2(e.DTSTYQ_ZX,1,0) as V112,
           nvl2(e.QTGHYQ,1,0) AS V12,
           1 as V131, nvl2(e.BSYQ_JZ,1,0) as V132,  nvl2(f.BSYQ_GX,1,0) as V133,
           nvl2(e.FJ,1,0) as V14,
           nvl2(e.BZ,1,0) as V15
    */
    --确定是否有案件
    select count(1) into i
    from bz_caseinstrelation n
    inner join pcc_project p on p.id = n.pid
    left join BZ_GHTJ_JZQYSZT e on n.cid = e.cid
    left join BZ_GHTJ_SZQYSZT f on n.cid = f.cid
    where p.id=v_pid;

    if i>0 then
        select dbms_lob.getlength(e.PTSS_GG) AS V32,  DBMS_LOB.GETLENGTH(e.PTSS_SZ) as V33,
               dbms_lob.getlength(e.WB) as V4 ,
               dbms_lob.getlength(f.GXJFSSS_ZT) as V51,  DBMS_LOB.GETLENGTH(f.GXJFSSS_XJ) as V52,  /*DBMS_LOB.GETLENGTH(f.GXJFSSS_SS)*/ 1 as V53,  DBMS_LOB.GETLENGTH(f.GXJFSSS_PS) as V54,
         DBMS_LOB.GETLENGTH(nvl2(f.GXJFSSS_HMCSYQ,f.GXJFSSS_HMCSYQ,nvl2(f.DTSTYQ_ZX_HMCSNLLKZL,f.DTSTYQ_ZX_HMCSNLLKZL,f.DTSTYQ_ZX_HMCSMYWRXJL))) as V55,
               nvl(dbms_lob.getlength(e.JTYQ_TCPJ_CDSHYQ),0)+nvl(DBMS_LOB.GETLENGTH(e.JTYQ_TCPJ_YZYQ),0) as V61,  DBMS_LOB.GETLENGTH(e.JTYQ_CRK) as V62,  DBMS_LOB.GETLENGTH(e.JTYQ_DK) as V63,  DBMS_LOB.GETLENGTH(e.JTYQ_QT) as V64,
               dbms_lob.getlength(e.CSSJYQ_ZT) as V71,  dbms_lob.getlength(e.CSSJYQ_KJXT) as V72,  dbms_lob.getlength(e.CSSJYQ_JQKZ) as V73,  dbms_lob.getlength(e.CSSJYQ_JZFG) as V74,  dbms_lob.getlength(e.CSSJYQ_JGZM) as V75,  dbms_lob.getlength(e.CSSJYQ_WQSZ) as V76,  dbms_lob.getlength(e.CSSJYQ_QT) as V77,
               dbms_lob.getlength(e.DXKJYQ) as V8,
               dbms_lob.getlength(e.JZSJYQ_ZT) as V91,  dbms_lob.getlength(e.JZSJYQ_DPBG) as V92,  dbms_lob.getlength(e.JZSJYQ_JZTR) as V93,  dbms_lob.getlength(e.JZSJYQ_JZJJ) as V94, dbms_lob.getlength(e.JZSJYQ_FSSS) as V95, dbms_lob.getlength(e.JZSJYQ_QT) as V96,
               dbms_lob.getlength(e.GHBHYQ_JQ) as V101,  dbms_lob.getlength(e.GHBHYQ_GDJT) as V102,  dbms_lob.getlength(e.GHBHYQ_DLDX) as V103,  dbms_lob.getlength(e.GHBHYQ_HD) as V104,  dbms_lob.getlength(e.GHBHYQ_CLBZ) as V105,  dbms_lob.getlength(e.GHBHYQ_LBSS) as V106,  dbms_lob.getlength(e.GHBHYQ_STHX) as V107,    dbms_lob.getlength(e.GHBHYQ_SDBHYQ) as V108,dbms_lob.getlength(e.GHBHYQ_QT) as V109,
               dbms_lob.getlength(e.DTSTYQ_ZT) as V111, dbms_lob.getlength(e.DTSTYQ_ZX) as V112,
               dbms_lob.getlength(e.QTGHYQ) AS V12,
               1 as V131, dbms_lob.getlength(e.BSYQ_JZ) as V132,  dbms_lob.getlength(f.BSYQ_GX) as V133,
               dbms_lob.getlength(e.FJ) as V14,
               1 as V15
          into
            V32, V33,
            V4,
            V51, V52, V53, V54,V55,
            V61, V62, V63, V64,
            V71, V72, V73, V74, V75, V76, V77,
            V8,
            V91, V92, V93, V94, V95, V96,
            V101, V102, V103, V104, V105, V106,V107, V108,V109,
            V111, V112,
            V12,
            V131, V132, V133,
            V14,
            V15
        from bz_caseinstrelation n
        inner join pcc_project p on p.id = n.pid
        left join BZ_GHTJ_JZQYSZT e on n.cid = e.cid
        left join BZ_GHTJ_SZQYSZT f on n.cid = f.cid
        where p.id=v_pid and rownum=1;
        /*
        from pcc_project p
        right join bz_caseinstrelation n on p.id = n.pid
        left join BZ_GHTJ_JZQYSZT e on n.cid = e.cid
        left join BZ_GHTJ_SZQYSZT f on n.cid = f.cid
        where  rownum=1 and n.pid=pid;
        */

    end if;


    --初始化20个
    vTab :=num_table();
    i :=0;
    while i<20 loop
        vTab.extend;
        i :=i+1;
    end loop;

    if jzOrSZ =0 or jzOrSZ =1 then --全部 或者建筑
            --开始编号
            curNum := 3;
            /*
            vTab(1):=1;--V32;  测试
            vTab(2):=0;--V32;
            vTab(3):=1;--V33;
            */
            vTab(1):=1;
            vTab(2):=V32;
            vTab(3):=V33;
            fTab := CalcRowNum(3,vTab,curNum,hasRow);
            F32 := vTab(2);
            F33 := vTab(3);
            curNum :=curNum+1;

            IF V4>0 THEN
                F4 := curNum;
                curNum := curNum+1;
            END IF;

        if jzOrSZ =0 then --全部，才纳入市政
            hasRow := false;
            vTab(1):= V51;
            vTab(2):= V52;
            vTab(3):= V53;
            vTab(4):= V54;
            vTab(5):= V55;
            fTab := CalcRowNum(5,vTab,curNum,hasRow);
            F51 := vTab(1);
            F52 := vTab(2);
            F53 := vTab(3);
            F54 := vTab(4);
            F55 := vTab(5);
            if hasRow = true then
               F5 := curNum;
               curNum := curNum+1;
            end if;

        end if;

            hasRow := false;
            vTab(1):= V61;
            vTab(2):= V62;
            vTab(3):= V63;
            vTab(4):= V64;
            fTab := CalcRowNum(4,vTab,curNum,hasRow);
            F61 := vTab(1);
            F62 := vTab(2);
            F63 := vTab(3);
            F64 := vTab(4);
            if hasRow = true then
               F6 := curNum;
               curNum := curNum+1;
            end if;

            hasRow := false;
            vTab(1):= V71;
            vTab(2):= V72;
            vTab(3):= V73;
            vTab(4):= V74;
            vTab(5):= V75;
            vTab(6):= V76;
            vTab(7):= V77;
            fTab := CalcRowNum(7,vTab,curNum,hasRow);
            F71 := vTab(1);
            F72 := vTab(2);
            F73 := vTab(3);
            F74 := vTab(4);
            F75 := vTab(5);
            F76 := vTab(6);
            F77 := vTab(7);
            if hasRow = true then
               F7 := curNum;
               curNum := curNum+1;
            end if;

            IF V8>0 THEN
                F8 := curNum;
                curNum := curNum+1;
            END IF;

            hasRow := false;
            vTab(1):= V91;
            vTab(2):= V92;
            vTab(3):= V93;
            vTab(4):= V94;
            vTab(5):= V95;
            vTab(6):= V96;
            fTab := CalcRowNum(6,vTab,curNum,hasRow);
            F91 := vTab(1);
            F92 := vTab(2);
            F93 := vTab(3);
            F94 := vTab(4);
            F95 := vTab(5);
            F96 := vTab(6);
            if hasRow = true then
               F9 := curNum;
               curNum := curNum+1;
            end if;

            hasRow := false;
            vTab(1):= V101;
            vTab(2):= V102;
            vTab(3):= V103;
            vTab(4):= V104;
            vTab(5):= V105;
            vTab(6):= V106;
            vTab(7):= V107;
            vTab(8):= V108;
      vTab(9):= V109;
            fTab := CalcRowNum(9,vTab,curNum,hasRow);
            F101 := vTab(1);
            F102 := vTab(2);
            F103 := vTab(3);
            F104 := vTab(4);
            F105 := vTab(5);
            F106 := vTab(6);
            F107 := vTab(7);
            F108 := vTab(8);
      F109 := vTab(9);
            if hasRow = true then
               F10 := curNum;
               curNum := curNum+1;
            end if;

            hasRow := false;
            vTab(1):= V111;
            vTab(2):= V112;
            fTab := CalcRowNum(2,vTab,curNum,hasRow);
            F111 := vTab(1);
            F112 := vTab(2);
            if hasRow = true then
               F11 := curNum;
               curNum := curNum+1;
            end if;

            IF V12>0 THEN
                F12 := curNum;
                curNum := curNum+1;
            END IF;

            hasRow := false;
            vTab(1):= V131;
            vTab(2):= V132;
            vTab(3):= 0;    --建筑，不纳入市政
        if jzOrSZ =0 then
            vTab(3):= V133; --全部，才纳入市政
        end if;

            fTab := CalcRowNum(3,vTab,curNum,hasRow);
            F131 := vTab(1);
            F132 := vTab(2);
            F133 := vTab(3);
            if hasRow = true then
               F13 := curNum;
               curNum := curNum+1;
            end if;

            IF V14>0 THEN
                F14 := curNum;
                curNum := curNum+1;
            END IF;

            --IF V151>0 THEN
                F15 := curNum;
                curNum := curNum+1;
            --END IF;
    else
        --市政
            --开始编号
            curNum := 2;

            hasRow := false;
            vTab(1):= V51;
            vTab(2):= V52;
            vTab(3):= V53;
            vTab(4):= V54;
      vTab(5):= V55;
            fTab := CalcRowNum(5,vTab,curNum,hasRow);
            F51 := vTab(1);
            F52 := vTab(2);
            F53 := vTab(3);
            F54 := vTab(4);
      F55 := vTab(5);
            if hasRow = true then
               F5 := curNum;
               curNum := curNum+1;
            end if;

            hasRow := false;
            vTab(1):= V131;
            vTab(2):= 0; --市政情况下，置白
            vTab(3):= V133;
            fTab := CalcRowNum(3,vTab,curNum,hasRow);
            F131 := vTab(1);
            F132 := vTab(2);
            F133 := vTab(3);
            if hasRow = true then
               F13 := curNum;
               curNum := curNum+1;
            end if;

            IF V14>0 THEN
                F14 := curNum;
                curNum := curNum+1;
            END IF;

            --IF V151>0 THEN
                F15 := curNum;
                curNum := curNum+1;
            --END IF;
    end if;

    --返回编号值
    if jzOrSZ =0 then --全部
        open numtable for
         SELECT F32 F32, F33 F33,
                F4 F4,
                F5 F5,  F51 F51,  F52 F52,  F53 F53,  F54 F54,F55 F55,
                F6 F6,  F61 F61,  F62 F62,  F63 F63,  F64 F64,
                F7 F7,  F71 F71,  F72 F72,  F73 F73,  F74 F74,  F75 F75,  F76 F76,  F77 F77,
                F8 F8,
                F9 F9,  F91 F91, F92 F92,  F93 F93, F94 F94, F95 F95, F96 F96,
                F10 F10,  F101 F101,  F102 F102,  F103 F103,  F104 F104,  F105 F105,  F106 F106,  F107 F107,  F108 F108,F109 F109,
                F11 F11,  F111 F111,  F112 F112,
                F12 F12,
                F13 F13,  F131 F131,  F132 F132,  F133 F133,
                F14 F14,
                F15 F15
            FROM DUAL;
    else if jzOrSZ =1 then --建筑
        open numtable for
         SELECT F32 F32, F33 F33,
                F4 F4,
              --F5 F5,  F51 F51,  F52 F52,  F53 F53,  F54 F54,F55 F55,
                F6 F6,  F61 F61,  F62 F62,  F63 F63,  F64 F64,
                F7 F7,  F71 F71,  F72 F72,  F73 F73,  F74 F74,  F75 F75,  F76 F76,  F77 F77,
                F8 F8,
                F9 F9,  F91 F91, F92 F92,  F93 F93, F94 F94, F95 F95, F96 F96,
                F10 F10,  F101 F101,  F102 F102,  F103 F103,  F104 F104,  F105 F105,  F106 F106,  F107 F107,  F108 F108,F109 F109,
                F11 F11,  F111 F111,  F112 F112,
                F12 F12,
                F13 F13,  F131 F131,  F132 F132,  --F133 F133,
                F14 F14,
                F15 F15
            FROM DUAL;
    else   --市政
        open numtable for
         SELECT
              --F32 F32, F33 F33,
              --F4 F4,
                F5 F5,  F51 F51,  F52 F52,  F53 F53,  F54 F54,F55 F55,
              /*F6 F6,  F61 F61,  F62 F62,  F63 F63,  F64 F64,
                F7 F7,  F71 F71,  F72 F72,  F73 F73,  F74 F74,  F75 F75,  F76 F76,  F77 F77,
                F8 F8,
                F9 F9,  F91 F91, F92 F92,  F93 F93, F94 F94, F95 F95, F96 F96,
                F10 F10,  F101 F101,  F102 F102,  F103 F103,  F104 F104,  F105 F105,  F106 F106,  F107 F107,  F108 F108,F109 F109,
                F11 F11,  F111 F111,  F112 F112,
                F12 F12,
                */
                F13 F13,  F131 F131,  F132 F132,  F133 F133,
                F14 F14,
                F15 F15
            FROM DUAL;
    end if;
  end if;


  end GetNumOfQYS;

  --修正数值转换字符串加上0
  function FixNum(num in number) return varchar2 is
    result varchar2(100);
  begin

    --return to_char(num,'fm9999999990.00');

    if num>=1 or num <=-1 then
        return to_char(num);
    end if;

    if num=0 then
        return '0';
    end if;

    if num>0 then
       return '0'||to_char(num);
    end if;

    if num<0 then
       return '-0'|| to_char(abs(num)) ;
    end if;

    return '0.00';
  end;


end NJ_REPORT;
/

