create function clearGraph(pid in Integer) return varchar2 is
  PRAGMA AUTONOMOUS_TRANSACTION;
  Result varchar2(40);
begin

  delete from APP_PreLandUse t where t.fk_project_id = pid;
  delete from APP_PreLandUseDetail t where t.fk_project_id = pid;
  delete from APP_PreLandUseSituation t where t.fk_project_id = pid;
  delete from APP_PreLandTerrestrial t where t.fk_project_id = pid;
  delete from APP_PreLandOwner t where t.fk_project_id = pid;
  delete from APP_PreLandKeyValue t where t.fk_project_id = pid;
  delete from APP_PreLandInspect t where t.fk_project_id = pid;
  delete from APP_PreLandBaseFarm t where t.fk_project_id = pid;
  delete from APP_PreLandUseIndex t where t.fk_project_id = pid;
  commit;
  return(Result);
end clearGraph;
/

