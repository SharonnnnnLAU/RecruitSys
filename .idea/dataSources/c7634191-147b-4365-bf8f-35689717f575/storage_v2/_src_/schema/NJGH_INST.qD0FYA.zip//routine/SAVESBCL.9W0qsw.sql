create procedure saveSBCL(v_cid   in integer,
                                       v_processName  in nvarchar2) is
begin
  for i in(select t.xh,t.clmc,t.bb,t.wh,t.zzyq,t.sdfs,t.dzwj,t.qj,t.ygsm from bz_sbcl_model t where processname = v_processName order by t.xh) loop
    insert into bz_sbcl(id,cid,xh,clmc,bb,wh,zzyq,sdfs,dzwj,qj,ygsm) values (s_bz_sbcl.nextval,v_cid,i.xh,i.clmc,i.bb,i.wh,i.zzyq,i.sdfs,i.dzwj,i.qj,i.ygsm);
    commit;
  end loop;
end;

/

