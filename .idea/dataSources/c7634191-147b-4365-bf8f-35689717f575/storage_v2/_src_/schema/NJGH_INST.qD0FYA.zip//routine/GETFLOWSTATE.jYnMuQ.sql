create function getflowState(flow  in   varchar2) return integer is
  result integer;
begin
  if  flow='???' then--???
    result:=4;
   elsif  flow<0  then--??
      result:=1;
      elsif  flow <=1  then--??
        result:=2;
        else --??
            result:=3;
            end  if;
  return(result);
end getflowState;
/

