create function chai_q(v_q in varchar2) return varchar2 is
  Result varchar2(40);
begin
    if  INSTR(v_q, '、', 1, 1)=0 then

       return v_q ;
    else
       return SUBSTR(v_q, 0, (INSTR(v_q, '、', 1, 1) - 1));
    end  if;
  return(Result);
end chai_q;
/

