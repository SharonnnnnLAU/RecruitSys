create package DP_Approve is

  -- Author  : XUZJ
  -- Created : 2017/12/25 17:57:42
  -- Purpose : ??????

  -- ??????????????????????
  procedure copyData2(v_id in integer, v_pid in integer);

  --  ???????????  ??id
  procedure updateProjectParallelid(pid1 in integer, pid2 in integer);

  -- ????????
  procedure copySupervisionData(v_pid in integer, v_parentId in integer);

  --  ???????? ????????????????
  -- modify  by czw  2018?4?12?17:28:55
  --v_ppid : parent project id
  procedure copyProjectBaseInfo(v_pid in integer, v_ppid in integer);

  procedure updateQj(mdid in integer);

  procedure createWhrwRelation(v_pid     in integer,
                               v_whrwPid in integer,
                               v_type    in varchar2);

  procedure createWhrwRelation2(v_pid     in integer,
                                v_whrwPid in integer,
                                v_type    in varchar2);

  procedure getWhrwRelationInfo(v_pid      in integer,
                                ref_cursor out sys_refcursor);

  procedure createRootMaterialDirectory(v_pid                in integer,
                                        v_directoryName      in varchar2,
                                        v_childDirectoryName in varchar2);

  procedure updateProjectCode1(v_pid in integer, v_projectCode in varchar2);
  procedure updateProjectCode2(v_pid in integer, v_projectCode in varchar2);
  procedure updateProjectCode3(v_projectCode in varchar2);
  procedure updateProjectCaseInfo(v_pid   in integer,
                                  v_pbid  in integer,
                                  v_bizid in varchar2);
  --???????????
  procedure deleteDkmxAndXzmx(v_Cid in integer);
  function get_ghhs_gcxkzh(v_cid in integer) return varchar2;

  --?????????????
  procedure deleteDataBeforeImportBSTJQD(v_cid in integer);
  --??????????? 
  procedure deleteDataBeforeImportBGXX(v_cid in integer);

  --??????  ---????
  procedure deleteDeclareProject(v_dmid in integer);
  --??????????
  procedure deleteJZVerifyDataByCid(v_cid in integer);

  procedure resetProjectCode(v_pid in integer, v_projectCode in varchar2);

  -- Created on 2020/5/9 by WUWK   续办复制pdt_projectbase数据
  PROCEDURE copyDataBase(OLDBASEID IN INTEGER, NEWBASEID IN INTEGER);
  
  --预办复制pdt_projectbase数据到bz_projectcase
  procedure copyBaseToCase(v_baseId in integer,v_pid in integer);
  
    --在办箱：复制bz_projectcase数据到pdt_projectbase
  procedure copyCaseToBase(v_pid in integer,v_baseId in integer);
  
  --更新预办项目编号和案卷编号
  procedure updateYbProjectCodeAndCaseCode(v_pid in integer, v_projectCode in varchar2, v_caseCode in varchar2, v_bizId in varchar2);

  --更新勘测定界字段来保存全要素勘测定界信息
  procedure updateQysKCDJInfo(v_pid    in integer,
                              v_jbr    in varchar2,
                              v_jbrq   in timestamp,
                              v_kcdw   in varchar2,
                              v_kcdjyq in varchar2);
end DP_Approve;
/

