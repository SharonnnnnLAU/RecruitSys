create function getMaxRoundNumber(v_pid in integer)
  return integer is
  result         integer;
  v_volumenumber integer;
  v_businessid   integer;
begin
  select c.volumenumber, p.fk_business_id
    into v_volumenumber, v_businessid
    from bz_projectcase c
    join bz_caseinstrelation ci
      on c.id = ci.cid
    join pcc_project p
      on p.id = ci.pid
   where p.id = v_pid;
  SELECT max(c.roundnumber)
    into result
    FROM PCC_PROJECTRELATION R
   INNER JOIN PCC_PROJECT P
      ON P.ID = R.FK_PROJECT_ID
    LEFT JOIN BZ_CASEINSTRELATION CR
      ON P.ID = CR.PID
    LEFT JOIN BZ_PROJECTCASE C
      ON CR.CID = C.ID
   WHERE R.FK_HEADPROJECT_ID IN
         (SELECT T.FK_HEADPROJECT_ID
            FROM PCC_PROJECTRELATION T
           WHERE T.FK_PROJECT_ID = v_pid)
     AND P.LIFESTATE <> '??'
     AND P.LIFESTATE != '??'
     and c.volumenumber = v_volumenumber
     and p.fk_business_id = v_businessid;
  return(result);
end getMaxRoundNumber;
/

