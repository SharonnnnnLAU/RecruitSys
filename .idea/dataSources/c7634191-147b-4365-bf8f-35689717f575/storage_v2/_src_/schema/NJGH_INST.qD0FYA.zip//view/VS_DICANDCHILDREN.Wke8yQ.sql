create view VS_DICANDCHILDREN as
select b.name,b.id as value1,wm_concat(ee.id) as children,b.fk_dictionaryvalue_id as parentid ,a.name as dicName, b.sortno
  from NJGH_DAP.dcc_dictionarytype a
  left join NJGH_DAP.dcc_dictionaryvalue b
    on a.id = b.fk_type_id
  left join NJGH_DAP.dcc_dictionaryvalue ee
    on b.id = ee.fk_dictionaryvalue_id
group by b.id , b.name ,a.name,b.fk_dictionaryvalue_id,b.sortno
order by b.sortno

/

